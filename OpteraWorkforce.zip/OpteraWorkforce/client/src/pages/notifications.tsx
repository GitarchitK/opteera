import { Layout } from "@/components/Layout/Layout";
import { NotificationCenter } from "@/components/Notifications/NotificationCenter";

export default function NotificationsPage() {
  return (
    <Layout>
      <NotificationCenter />
    </Layout>
  );
}
