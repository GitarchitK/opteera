import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { formatDateTime } from "@/utils/timezone";

export function DateTimeWidget() {
  const [currentDateTime, setCurrentDateTime] = useState(() => formatDateTime(new Date()));

  useEffect(() => {
    const updateDateTime = () => {
      setCurrentDateTime(formatDateTime(new Date()));
    };

    // Update immediately
    updateDateTime();
    
    // Update every second
    const interval = setInterval(updateDateTime, 1000);
    
    return () => clearInterval(interval);
  }, []);

  return (
    <Card className="bg-white dark:bg-dark-card border dark:border-dark-border">
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
              Good morning!
            </h2>
            <p className="text-gray-600 dark:text-gray-400">
              Here's what's happening in your workforce today
            </p>
          </div>
          <div className="text-right">
            <p className="text-lg font-semibold text-gray-900 dark:text-white" data-testid="text-current-time">
              {currentDateTime.time}
            </p>
            <p className="text-sm text-gray-500 dark:text-gray-400" data-testid="text-current-date">
              {currentDateTime.date}
            </p>
            <p className="text-xs text-gray-400 dark:text-gray-500" data-testid="text-timezone">
              ({currentDateTime.timezone})
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
