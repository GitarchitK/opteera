import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useFirestoreCollection } from "@/hooks/useFirestore";
import { Attendance, User } from "@shared/schema";
import { where } from "firebase/firestore";
import { formatDateString } from "@/utils/dateHelpers";
import { formatTime } from "@/utils/timezone";

interface RecentCheckIn {
  user: User;
  attendance: Attendance;
}

export function AttendanceWidget() {
  const today = formatDateString(new Date());
  
  const { data: todayAttendance } = useFirestoreCollection<Attendance>(
    "attendance",
    [where("date", "==", today)]
  );

  const { data: users } = useFirestoreCollection<User>("users");

  // Calculate attendance stats
  const attendanceStats = {
    present: todayAttendance.filter(a => a.status === "present").length,
    absent: todayAttendance.filter(a => a.status === "absent").length,
    onLeave: todayAttendance.filter(a => a.status === "on-leave").length,
  };

  // Get recent check-ins (those with check-in time today)
  const recentCheckIns: RecentCheckIn[] = todayAttendance
    .filter(attendance => attendance.checkInTime)
    .sort((a, b) => {
      if (!a.checkInTime || !b.checkInTime) return 0;
      return b.checkInTime.getTime() - a.checkInTime.getTime();
    })
    .slice(0, 2)
    .map(attendance => {
      const user = users.find(u => u.uid === attendance.userId);
      return { user: user!, attendance };
    })
    .filter(item => item.user);

  return (
    <Card className="lg:col-span-2 bg-white dark:bg-dark-card border dark:border-dark-border">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
            Today's Attendance
          </h3>
          <Button variant="ghost" className="text-primary hover:text-blue-700 text-sm font-medium" data-testid="button-view-all-attendance">
            View All
          </Button>
        </div>
        
        <div className="grid grid-cols-3 gap-4 mb-6">
          <div className="text-center">
            <div className="w-16 h-16 bg-green-100 dark:bg-green-900/30 rounded-full flex items-center justify-center mx-auto mb-2">
              <i className="fas fa-check text-green-600 dark:text-green-400 text-xl"></i>
            </div>
            <p className="text-2xl font-bold text-gray-900 dark:text-white" data-testid="text-present-count">
              {attendanceStats.present}
            </p>
            <p className="text-sm text-gray-500 dark:text-gray-400">Present</p>
          </div>
          <div className="text-center">
            <div className="w-16 h-16 bg-red-100 dark:bg-red-900/30 rounded-full flex items-center justify-center mx-auto mb-2">
              <i className="fas fa-times text-red-600 dark:text-red-400 text-xl"></i>
            </div>
            <p className="text-2xl font-bold text-gray-900 dark:text-white" data-testid="text-absent-count">
              {attendanceStats.absent}
            </p>
            <p className="text-sm text-gray-500 dark:text-gray-400">Absent</p>
          </div>
          <div className="text-center">
            <div className="w-16 h-16 bg-yellow-100 dark:bg-yellow-900/30 rounded-full flex items-center justify-center mx-auto mb-2">
              <i className="fas fa-calendar text-yellow-600 dark:text-yellow-400 text-xl"></i>
            </div>
            <p className="text-2xl font-bold text-gray-900 dark:text-white" data-testid="text-on-leave-count">
              {attendanceStats.onLeave}
            </p>
            <p className="text-sm text-gray-500 dark:text-gray-400">On Leave</p>
          </div>
        </div>

        {/* Recent Check-ins */}
        <div className="space-y-3">
          {recentCheckIns.length > 0 ? (
            recentCheckIns.map((item, index) => (
              <div
                key={item.attendance.attendanceId}
                className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg"
                data-testid={`card-recent-checkin-${index}`}
              >
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
                    <span className="text-white font-medium">
                      {item.user.name.split(' ').map(n => n[0]).join('').slice(0, 2)}
                    </span>
                  </div>
                  <div>
                    <p className="font-medium text-gray-900 dark:text-white">
                      {item.user.name}
                    </p>
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      {item.user.position}
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-sm font-medium text-gray-900 dark:text-white">
                    {item.attendance.checkInTime && formatTime(item.attendance.checkInTime)}
                  </p>
                  <p className="text-xs text-green-600 dark:text-green-400">
                    On time
                  </p>
                </div>
              </div>
            ))
          ) : (
            <div className="text-center py-8 text-gray-500 dark:text-gray-400">
              <p>No check-ins recorded today</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
