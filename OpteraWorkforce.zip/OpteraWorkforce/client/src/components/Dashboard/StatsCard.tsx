import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";

interface StatsCardProps {
  title: string;
  value: string | number;
  change?: string;
  changeType?: "increase" | "decrease" | "neutral";
  icon: React.ReactNode;
  iconBgColor: string;
  testId?: string;
}

export function StatsCard({ 
  title, 
  value, 
  change, 
  changeType = "neutral", 
  icon, 
  iconBgColor,
  testId 
}: StatsCardProps) {
  const changeColors = {
    increase: "text-green-600 dark:text-green-400",
    decrease: "text-red-600 dark:text-red-400", 
    neutral: "text-yellow-600 dark:text-yellow-400"
  };

  const changeIcons = {
    increase: "fas fa-arrow-up",
    decrease: "fas fa-arrow-down",
    neutral: "fas fa-minus"
  };

  return (
    <Card className="bg-white dark:bg-dark-card border dark:border-dark-border">
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-600 dark:text-gray-400">
              {title}
            </p>
            <p className="text-3xl font-bold text-gray-900 dark:text-white" data-testid={testId}>
              {value}
            </p>
            {change && (
              <p className={cn("text-sm", changeColors[changeType])}>
                <i className={cn(changeIcons[changeType], "text-xs mr-1")}></i>
                {change}
              </p>
            )}
          </div>
          <div className={cn(
            "w-12 h-12 rounded-lg flex items-center justify-center",
            iconBgColor
          )}>
            {icon}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
