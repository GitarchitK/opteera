import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/hooks/useAuth";
import { useFirestoreCollection } from "@/hooks/useFirestore";
import { Attendance, User } from "@shared/schema";
import { where, orderBy } from "firebase/firestore";
import { formatDateString, formatDisplayDate } from "@/utils/dateHelpers";
import { formatTime } from "@/utils/timezone";
import { ClockInOut } from "./ClockInOut";

export function AttendanceManagement() {
  const { userProfile } = useAuth();
  const [selectedDate, setSelectedDate] = useState(formatDateString(new Date()));
  
  const { data: users } = useFirestoreCollection<User>("users");
  const { data: allAttendance } = useFirestoreCollection<Attendance>(
    "attendance",
    [orderBy("date", "desc")]
  );

  // Filter attendance based on user role and selected date
  const attendanceData = userProfile?.role === "admin" 
    ? allAttendance.filter(a => a.date === selectedDate)
    : allAttendance.filter(a => a.userId === userProfile?.uid);

  const myAttendance = allAttendance.filter(a => a.userId === userProfile?.uid);

  const getStatusColor = (status: string) => {
    switch (status) {
      case "present": return "bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400";
      case "absent": return "bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-400";
      case "late": return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-400";
      case "on-leave": return "bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-400";
      default: return "bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-400";
    }
  };

  const getUserName = (userId: string) => {
    const user = users.find(u => u.uid === userId);
    return user?.name || "Unknown User";
  };

  const calculateMonthlyStats = () => {
    const currentMonth = new Date().getMonth();
    const currentYear = new Date().getFullYear();
    
    const monthlyAttendance = myAttendance.filter(a => {
      const attendanceDate = new Date(a.date);
      return attendanceDate.getMonth() === currentMonth && attendanceDate.getFullYear() === currentYear;
    });

    const totalDays = monthlyAttendance.length;
    const presentDays = monthlyAttendance.filter(a => a.status === "present").length;
    const totalHours = monthlyAttendance.reduce((sum, a) => sum + a.totalHours, 0);
    const overtimeHours = monthlyAttendance.reduce((sum, a) => sum + a.overtimeHours, 0);

    return { totalDays, presentDays, totalHours, overtimeHours };
  };

  const monthlyStats = calculateMonthlyStats();

  if (userProfile?.role === "admin") {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Attendance Management</h1>
          <div className="flex items-center space-x-4">
            <Label htmlFor="date">Date:</Label>
            <Input
              id="date"
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="w-auto"
              data-testid="input-attendance-date"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card className="bg-white dark:bg-dark-card border dark:border-dark-border">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Present</p>
                  <p className="text-3xl font-bold text-green-600 dark:text-green-400">
                    {attendanceData.filter(a => a.status === "present").length}
                  </p>
                </div>
                <div className="w-12 h-12 bg-green-100 dark:bg-green-900/30 rounded-lg flex items-center justify-center">
                  <i className="fas fa-check text-green-600 dark:text-green-400 text-xl"></i>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white dark:bg-dark-card border dark:border-dark-border">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Absent</p>
                  <p className="text-3xl font-bold text-red-600 dark:text-red-400">
                    {attendanceData.filter(a => a.status === "absent").length}
                  </p>
                </div>
                <div className="w-12 h-12 bg-red-100 dark:bg-red-900/30 rounded-lg flex items-center justify-center">
                  <i className="fas fa-times text-red-600 dark:text-red-400 text-xl"></i>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white dark:bg-dark-card border dark:border-dark-border">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600 dark:text-gray-400">On Leave</p>
                  <p className="text-3xl font-bold text-blue-600 dark:text-blue-400">
                    {attendanceData.filter(a => a.status === "on-leave").length}
                  </p>
                </div>
                <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900/30 rounded-lg flex items-center justify-center">
                  <i className="fas fa-calendar text-blue-600 dark:text-blue-400 text-xl"></i>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white dark:bg-dark-card border dark:border-dark-border">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Late</p>
                  <p className="text-3xl font-bold text-yellow-600 dark:text-yellow-400">
                    {attendanceData.filter(a => a.status === "late").length}
                  </p>
                </div>
                <div className="w-12 h-12 bg-yellow-100 dark:bg-yellow-900/30 rounded-lg flex items-center justify-center">
                  <i className="fas fa-clock text-yellow-600 dark:text-yellow-400 text-xl"></i>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <Card className="bg-white dark:bg-dark-card border dark:border-dark-border">
          <CardHeader>
            <CardTitle>Attendance for {formatDisplayDate(new Date(selectedDate))}</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Employee</TableHead>
                  <TableHead>Check In</TableHead>
                  <TableHead>Check Out</TableHead>
                  <TableHead>Total Hours</TableHead>
                  <TableHead>Overtime</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {attendanceData.map((attendance) => (
                  <TableRow key={attendance.attendanceId} data-testid={`row-attendance-${attendance.attendanceId}`}>
                    <TableCell className="font-medium">
                      {getUserName(attendance.userId)}
                    </TableCell>
                    <TableCell>
                      {attendance.checkInTime ? formatTime(attendance.checkInTime) : "-"}
                    </TableCell>
                    <TableCell>
                      {attendance.checkOutTime ? formatTime(attendance.checkOutTime) : "-"}
                    </TableCell>
                    <TableCell>{attendance.totalHours.toFixed(2)} hrs</TableCell>
                    <TableCell>
                      {attendance.overtimeHours > 0 ? (
                        <span className="text-orange-600 dark:text-orange-400">
                          {attendance.overtimeHours.toFixed(2)} hrs
                        </span>
                      ) : (
                        "-"
                      )}
                    </TableCell>
                    <TableCell>
                      <Badge className={getStatusColor(attendance.status)}>
                        {attendance.status}
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            
            {attendanceData.length === 0 && (
              <div className="text-center py-8">
                <p className="text-gray-500 dark:text-gray-400">
                  No attendance records found for this date.
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    );
  }

  // Employee/Contractor view
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
          {userProfile?.role === "contractor" ? "Time Tracking" : "My Attendance"}
        </h1>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Clock In/Out Widget */}
        <ClockInOut />

        {/* Monthly Summary */}
        <Card className="bg-white dark:bg-dark-card border dark:border-dark-border">
          <CardHeader>
            <CardTitle>This Month's Summary</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center">
                <p className="text-2xl font-bold text-primary">{monthlyStats.presentDays}</p>
                <p className="text-sm text-gray-600 dark:text-gray-400">Days Present</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-gray-900 dark:text-white">{monthlyStats.totalDays}</p>
                <p className="text-sm text-gray-600 dark:text-gray-400">Total Days</p>
              </div>
            </div>
            
            <div className="pt-4 border-t border-gray-200 dark:border-gray-700">
              <div className="flex justify-between mb-2">
                <span className="text-sm text-gray-600 dark:text-gray-400">Total Hours:</span>
                <span className="font-medium">{monthlyStats.totalHours.toFixed(2)}</span>
              </div>
              
              {monthlyStats.overtimeHours > 0 && (
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600 dark:text-gray-400">Overtime:</span>
                  <span className="font-medium text-orange-600 dark:text-orange-400">
                    {monthlyStats.overtimeHours.toFixed(2)} hrs
                  </span>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Recent Activity */}
        <Card className="bg-white dark:bg-dark-card border dark:border-dark-border">
          <CardHeader>
            <CardTitle>Recent Activity</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {myAttendance.slice(0, 5).map((attendance) => (
                <div
                  key={attendance.attendanceId}
                  className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg"
                  data-testid={`card-my-attendance-${attendance.attendanceId}`}
                >
                  <div>
                    <p className="font-medium text-gray-900 dark:text-white">
                      {formatDisplayDate(new Date(attendance.date))}
                    </p>
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      {attendance.totalHours.toFixed(2)} hours
                    </p>
                  </div>
                  <Badge className={getStatusColor(attendance.status)}>
                    {attendance.status}
                  </Badge>
                </div>
              ))}
              
              {myAttendance.length === 0 && (
                <div className="text-center py-4">
                  <p className="text-gray-500 dark:text-gray-400 text-sm">
                    No attendance records yet
                  </p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Detailed History */}
      <Card className="bg-white dark:bg-dark-card border dark:border-dark-border">
        <CardHeader>
          <CardTitle>Attendance History</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Date</TableHead>
                <TableHead>Check In</TableHead>
                <TableHead>Check Out</TableHead>
                <TableHead>Total Hours</TableHead>
                <TableHead>Overtime</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {myAttendance.slice(0, 10).map((attendance) => (
                <TableRow key={attendance.attendanceId}>
                  <TableCell className="font-medium">
                    {formatDisplayDate(new Date(attendance.date))}
                  </TableCell>
                  <TableCell>
                    {attendance.checkInTime ? formatTime(attendance.checkInTime) : "-"}
                  </TableCell>
                  <TableCell>
                    {attendance.checkOutTime ? formatTime(attendance.checkOutTime) : "-"}
                  </TableCell>
                  <TableCell>{attendance.totalHours.toFixed(2)} hrs</TableCell>
                  <TableCell>
                    {attendance.overtimeHours > 0 ? (
                      <span className="text-orange-600 dark:text-orange-400">
                        {attendance.overtimeHours.toFixed(2)} hrs
                      </span>
                    ) : (
                      "-"
                    )}
                  </TableCell>
                  <TableCell>
                    <Badge className={getStatusColor(attendance.status)}>
                      {attendance.status}
                    </Badge>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
