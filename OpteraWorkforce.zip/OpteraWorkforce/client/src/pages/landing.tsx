import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export function LandingPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800">
      {/* Hero Section */}
      <div className="container mx-auto px-6 py-16">
        <div className="text-center mb-16">
          <Badge className="mb-6 bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-400">
            Modern Workforce Management
          </Badge>
          <h1 className="text-5xl md:text-6xl font-bold text-gray-900 dark:text-white mb-6">
            Welcome to{" "}
            <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              Optera
            </span>
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 mb-8 max-w-3xl mx-auto">
            Streamline your employee and contractor management with our comprehensive platform. 
            Track attendance, manage projects, process payroll, and keep your workforce organized.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/register">
              <Button size="lg" className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 text-lg" data-testid="button-register-company">
                <i className="fas fa-building mr-2"></i>
                Register Your Company
              </Button>
            </Link>
            <Link href="/login">
              <Button variant="outline" size="lg" className="px-8 py-3 text-lg border-blue-600 text-blue-600 hover:bg-blue-50 dark:border-blue-400 dark:text-blue-400" data-testid="button-login">
                <i className="fas fa-sign-in-alt mr-2"></i>
                Login
              </Button>
            </Link>
          </div>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm border-0 shadow-lg hover:shadow-xl transition-shadow">
            <CardContent className="p-8">
              <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900/20 rounded-lg flex items-center justify-center mb-4">
                <i className="fas fa-users text-2xl text-blue-600 dark:text-blue-400"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-3">Employee Management</h3>
              <p className="text-gray-600 dark:text-gray-300">
                Manage employees and contractors with role-based access, profiles, and comprehensive user administration.
              </p>
            </CardContent>
          </Card>

          <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm border-0 shadow-lg hover:shadow-xl transition-shadow">
            <CardContent className="p-8">
              <div className="w-12 h-12 bg-green-100 dark:bg-green-900/20 rounded-lg flex items-center justify-center mb-4">
                <i className="fas fa-clock text-2xl text-green-600 dark:text-green-400"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-3">Time Tracking</h3>
              <p className="text-gray-600 dark:text-gray-300">
                Real-time attendance tracking with clock-in/out features, overtime calculation, and detailed reports.
              </p>
            </CardContent>
          </Card>

          <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm border-0 shadow-lg hover:shadow-xl transition-shadow">
            <CardContent className="p-8">
              <div className="w-12 h-12 bg-purple-100 dark:bg-purple-900/20 rounded-lg flex items-center justify-center mb-4">
                <i className="fas fa-project-diagram text-2xl text-purple-600 dark:text-purple-400"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-3">Project Management</h3>
              <p className="text-gray-600 dark:text-gray-300">
                Organize projects, assign tasks, track progress, and manage deadlines with intuitive project tools.
              </p>
            </CardContent>
          </Card>

          <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm border-0 shadow-lg hover:shadow-xl transition-shadow">
            <CardContent className="p-8">
              <div className="w-12 h-12 bg-orange-100 dark:bg-orange-900/20 rounded-lg flex items-center justify-center mb-4">
                <i className="fas fa-calendar-alt text-2xl text-orange-600 dark:text-orange-400"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-3">Leave Management</h3>
              <p className="text-gray-600 dark:text-gray-300">
                Streamlined leave requests, approval workflows, and vacation tracking for better workforce planning.
              </p>
            </CardContent>
          </Card>

          <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm border-0 shadow-lg hover:shadow-xl transition-shadow">
            <CardContent className="p-8">
              <div className="w-12 h-12 bg-red-100 dark:bg-red-900/20 rounded-lg flex items-center justify-center mb-4">
                <i className="fas fa-file-invoice-dollar text-2xl text-red-600 dark:text-red-400"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-3">Automated Invoicing</h3>
              <p className="text-gray-600 dark:text-gray-300">
                Generate monthly invoices automatically with detailed breakdowns, PDF downloads, and payment tracking.
              </p>
            </CardContent>
          </Card>

          <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm border-0 shadow-lg hover:shadow-xl transition-shadow">
            <CardContent className="p-8">
              <div className="w-12 h-12 bg-indigo-100 dark:bg-indigo-900/20 rounded-lg flex items-center justify-center mb-4">
                <i className="fas fa-bell text-2xl text-indigo-600 dark:text-indigo-400"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-3">Notifications</h3>
              <p className="text-gray-600 dark:text-gray-300">
                Keep everyone informed with real-time notifications, announcements, and system updates.
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Stats Section */}
        <div className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-sm rounded-2xl p-12">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
              Trusted by Modern Companies
            </h2>
            <p className="text-gray-600 dark:text-gray-300 text-lg">
              Join thousands of organizations streamlining their workforce management
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
            <div>
              <div className="text-4xl font-bold text-blue-600 dark:text-blue-400 mb-2">10,000+</div>
              <div className="text-gray-600 dark:text-gray-300">Employees Managed</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-green-600 dark:text-green-400 mb-2">500+</div>
              <div className="text-gray-600 dark:text-gray-300">Companies Using Optera</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-purple-600 dark:text-purple-400 mb-2">99.9%</div>
              <div className="text-gray-600 dark:text-gray-300">Uptime Reliability</div>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-gray-900 dark:bg-black text-white py-12">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="col-span-1 md:col-span-2">
              <h3 className="text-2xl font-bold mb-4">Optera</h3>
              <p className="text-gray-300 mb-4">
                Modern workforce management platform designed to streamline your HR operations and boost productivity.
              </p>
              <div className="flex space-x-4">
                <Button variant="ghost" size="sm" className="text-gray-300 hover:text-white">
                  <i className="fab fa-twitter"></i>
                </Button>
                <Button variant="ghost" size="sm" className="text-gray-300 hover:text-white">
                  <i className="fab fa-linkedin"></i>
                </Button>
                <Button variant="ghost" size="sm" className="text-gray-300 hover:text-white">
                  <i className="fab fa-github"></i>
                </Button>
              </div>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Features</h4>
              <ul className="space-y-2 text-gray-300">
                <li>Employee Management</li>
                <li>Time Tracking</li>
                <li>Project Management</li>
                <li>Leave Management</li>
                <li>Automated Invoicing</li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Support</h4>
              <ul className="space-y-2 text-gray-300">
                <li>Documentation</li>
                <li>Help Center</li>
                <li>Contact Support</li>
                <li>System Status</li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 Optera. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}