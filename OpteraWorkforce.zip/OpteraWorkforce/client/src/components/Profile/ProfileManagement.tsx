import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { useAuth } from "@/hooks/useAuth";
import { updateFirestoreDocument } from "@/hooks/useFirestore";
import { updatePassword, EmailAuthProvider, reauthenticateWithCredential } from "firebase/auth";
import { auth } from "@/lib/firebase";
import { formatDisplayDate } from "@/utils/dateHelpers";
import { useToast } from "@/hooks/use-toast";

export function ProfileManagement() {
  const { userProfile, currentUser } = useAuth();
  const { toast } = useToast();
  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const [isChangingPassword, setIsChangingPassword] = useState(false);
  const [loading, setLoading] = useState(false);

  const [profileData, setProfileData] = useState({
    name: userProfile?.name || "",
    position: userProfile?.position || "",
  });

  const [passwordData, setPasswordData] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  });

  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase();
  };

  const getRoleBadgeColor = (role: string) => {
    switch (role) {
      case "admin": return "bg-purple-100 text-purple-800 dark:bg-purple-900/20 dark:text-purple-400";
      case "employee": return "bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-400";
      case "contractor": return "bg-orange-100 text-orange-800 dark:bg-orange-900/20 dark:text-orange-400";
      default: return "bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-400";
    }
  };

  const handleUpdateProfile = async () => {
    if (!profileData.name.trim()) {
      toast({
        title: "Error",
        description: "Name is required.",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    try {
      await updateFirestoreDocument("users", userProfile!.uid, {
        name: profileData.name,
        position: profileData.position,
      });

      toast({
        title: "Success",
        description: "Profile updated successfully!",
      });

      setIsEditingProfile(false);
    } catch (error) {
      console.error("Update profile error:", error);
      toast({
        title: "Error",
        description: "Failed to update profile.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleChangePassword = async () => {
    if (!passwordData.currentPassword || !passwordData.newPassword || !passwordData.confirmPassword) {
      toast({
        title: "Error",
        description: "Please fill in all password fields.",
        variant: "destructive",
      });
      return;
    }

    if (passwordData.newPassword !== passwordData.confirmPassword) {
      toast({
        title: "Error",
        description: "New passwords do not match.",
        variant: "destructive",
      });
      return;
    }

    if (passwordData.newPassword.length < 6) {
      toast({
        title: "Error",
        description: "New password must be at least 6 characters long.",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    try {
      if (!currentUser?.email) {
        throw new Error("No authenticated user found");
      }

      // Re-authenticate user before changing password
      const credential = EmailAuthProvider.credential(
        currentUser.email,
        passwordData.currentPassword
      );
      
      await reauthenticateWithCredential(currentUser, credential);
      await updatePassword(currentUser, passwordData.newPassword);

      toast({
        title: "Success",
        description: "Password changed successfully!",
      });

      setIsChangingPassword(false);
      setPasswordData({
        currentPassword: "",
        newPassword: "",
        confirmPassword: "",
      });
    } catch (error: any) {
      console.error("Change password error:", error);
      
      let errorMessage = "Failed to change password.";
      if (error.code === "auth/wrong-password") {
        errorMessage = "Current password is incorrect.";
      } else if (error.code === "auth/weak-password") {
        errorMessage = "New password is too weak.";
      }

      toast({
        title: "Error",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  if (!userProfile) {
    return (
      <div className="text-center py-8">
        <p className="text-gray-500 dark:text-gray-400">Loading profile...</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Profile</h1>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Profile Overview */}
        <Card className="lg:col-span-2 bg-white dark:bg-dark-card border dark:border-dark-border">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>Profile Information</span>
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  setIsEditingProfile(!isEditingProfile);
                  if (!isEditingProfile) {
                    setProfileData({
                      name: userProfile.name,
                      position: userProfile.position || "",
                    });
                  }
                }}
                data-testid="button-edit-profile"
              >
                {isEditingProfile ? (
                  <>
                    <i className="fas fa-times mr-2"></i>
                    Cancel
                  </>
                ) : (
                  <>
                    <i className="fas fa-edit mr-2"></i>
                    Edit
                  </>
                )}
              </Button>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-center space-x-6">
              <Avatar className="h-20 w-20">
                <AvatarFallback className="bg-primary text-primary-foreground text-2xl">
                  {getInitials(userProfile.name)}
                </AvatarFallback>
              </Avatar>
              <div>
                <Badge className={getRoleBadgeColor(userProfile.role)}>
                  {userProfile.role}
                </Badge>
                <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                  Member since {formatDisplayDate(userProfile.createdAt)}
                </p>
              </div>
            </div>

            {isEditingProfile ? (
              <div className="space-y-4">
                <div>
                  <Label htmlFor="name">Full Name *</Label>
                  <Input
                    id="name"
                    value={profileData.name}
                    onChange={(e) => setProfileData(prev => ({ ...prev, name: e.target.value }))}
                    placeholder="Enter your full name"
                    data-testid="input-profile-name"
                  />
                </div>
                
                <div>
                  <Label htmlFor="position">Position</Label>
                  <Input
                    id="position"
                    value={profileData.position}
                    onChange={(e) => setProfileData(prev => ({ ...prev, position: e.target.value }))}
                    placeholder="Enter your position/title"
                    data-testid="input-profile-position"
                  />
                </div>
                
                <div className="flex space-x-2 pt-4">
                  <Button
                    onClick={handleUpdateProfile}
                    disabled={loading}
                    className="bg-primary hover:bg-blue-700"
                    data-testid="button-save-profile"
                  >
                    {loading ? (
                      <>
                        <i className="fas fa-spinner fa-spin mr-2"></i>
                        Saving...
                      </>
                    ) : (
                      "Save Changes"
                    )}
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => setIsEditingProfile(false)}
                    disabled={loading}
                  >
                    Cancel
                  </Button>
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-6">
                  <div>
                    <Label className="text-sm text-gray-600 dark:text-gray-400">Full Name</Label>
                    <p className="font-medium text-gray-900 dark:text-white">{userProfile.name}</p>
                  </div>
                  
                  <div>
                    <Label className="text-sm text-gray-600 dark:text-gray-400">Email</Label>
                    <p className="font-medium text-gray-900 dark:text-white">{userProfile.email}</p>
                  </div>
                  
                  <div>
                    <Label className="text-sm text-gray-600 dark:text-gray-400">Position</Label>
                    <p className="font-medium text-gray-900 dark:text-white">
                      {userProfile.position || "Not specified"}
                    </p>
                  </div>
                  
                  <div>
                    <Label className="text-sm text-gray-600 dark:text-gray-400">Role</Label>
                    <p className="font-medium text-gray-900 dark:text-white capitalize">
                      {userProfile.role}
                    </p>
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Compensation & Security */}
        <div className="space-y-6">
          {/* Compensation Info */}
          <Card className="bg-white dark:bg-dark-card border dark:border-dark-border">
            <CardHeader>
              <CardTitle>Compensation</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {userProfile.role === "employee" && (
                <div>
                  <Label className="text-sm text-gray-600 dark:text-gray-400">Monthly Salary</Label>
                  <p className="text-2xl font-bold text-primary">
                    ${userProfile.salary?.toLocaleString() || 0}
                  </p>
                </div>
              )}
              
              {userProfile.role === "contractor" && (
                <div>
                  <Label className="text-sm text-gray-600 dark:text-gray-400">Hourly Rate</Label>
                  <p className="text-2xl font-bold text-primary">
                    ${userProfile.contractRate || 0}/hr
                  </p>
                </div>
              )}
              
              {userProfile.overtimeRate && (
                <div>
                  <Label className="text-sm text-gray-600 dark:text-gray-400">Overtime Rate</Label>
                  <p className="font-medium text-gray-900 dark:text-white">
                    ${userProfile.overtimeRate}/hr
                  </p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Security Settings */}
          <Card className="bg-white dark:bg-dark-card border dark:border-dark-border">
            <CardHeader>
              <CardTitle>Security</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium text-gray-900 dark:text-white">Password</p>
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    Last changed: Unknown
                  </p>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setIsChangingPassword(!isChangingPassword)}
                  data-testid="button-change-password"
                >
                  Change
                </Button>
              </div>

              {isChangingPassword && (
                <>
                  <Separator />
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="currentPassword">Current Password *</Label>
                      <Input
                        id="currentPassword"
                        type="password"
                        value={passwordData.currentPassword}
                        onChange={(e) => setPasswordData(prev => ({ ...prev, currentPassword: e.target.value }))}
                        placeholder="Enter current password"
                        data-testid="input-current-password"
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="newPassword">New Password *</Label>
                      <Input
                        id="newPassword"
                        type="password"
                        value={passwordData.newPassword}
                        onChange={(e) => setPasswordData(prev => ({ ...prev, newPassword: e.target.value }))}
                        placeholder="Enter new password"
                        data-testid="input-new-password"
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="confirmPassword">Confirm New Password *</Label>
                      <Input
                        id="confirmPassword"
                        type="password"
                        value={passwordData.confirmPassword}
                        onChange={(e) => setPasswordData(prev => ({ ...prev, confirmPassword: e.target.value }))}
                        placeholder="Confirm new password"
                        data-testid="input-confirm-password"
                      />
                    </div>
                    
                    <div className="flex space-x-2 pt-2">
                      <Button
                        onClick={handleChangePassword}
                        disabled={loading}
                        size="sm"
                        className="bg-primary hover:bg-blue-700"
                        data-testid="button-save-password"
                      >
                        {loading ? (
                          <>
                            <i className="fas fa-spinner fa-spin mr-2"></i>
                            Changing...
                          </>
                        ) : (
                          "Change Password"
                        )}
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          setIsChangingPassword(false);
                          setPasswordData({
                            currentPassword: "",
                            newPassword: "",
                            confirmPassword: "",
                          });
                        }}
                        disabled={loading}
                      >
                        Cancel
                      </Button>
                    </div>
                  </div>
                </>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
