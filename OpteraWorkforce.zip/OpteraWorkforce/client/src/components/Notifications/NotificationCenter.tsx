import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Checkbox } from "@/components/ui/checkbox";
import { useAuth } from "@/hooks/useAuth";
import { useFirestoreCollection, addFirestoreDocument, updateFirestoreDocument } from "@/hooks/useFirestore";
import { Notification, User, InsertNotification } from "@shared/schema";
import { where, orderBy } from "firebase/firestore";
import { formatDisplayDate } from "@/utils/dateHelpers";
import { useToast } from "@/hooks/use-toast";

export function NotificationCenter() {
  const { userProfile } = useAuth();
  const { toast } = useToast();
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState("all");

  const { data: allNotifications } = useFirestoreCollection<Notification>(
    "notifications",
    [orderBy("createdAt", "desc")]
  );
  const { data: users } = useFirestoreCollection<User>("users");

  // Filter notifications based on user role and targeting
  const notifications = allNotifications.filter(notification => {
    if (userProfile?.role === "admin") {
      return true; // Admins see all notifications
    }

    // Check if notification targets this user
    const targetsAll = notification.targetUsers.includes("all");
    const targetsUser = notification.targetUsers.includes(userProfile?.uid || "");
    const targetsRole = notification.targetRoles?.includes(userProfile?.role || "employee");

    return targetsAll || targetsUser || targetsRole;
  });

  const [newNotification, setNewNotification] = useState<InsertNotification>({
    title: "",
    message: "",
    targetUsers: ["all"],
    targetRoles: [],
    type: "announcement",
    priority: "medium",
    isRead: {},
  });

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high": return "bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-400";
      case "medium": return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-400";
      case "low": return "bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400";
      default: return "bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-400";
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case "announcement": return "bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-400";
      case "system": return "bg-purple-100 text-purple-800 dark:bg-purple-900/20 dark:text-purple-400";
      case "reminder": return "bg-orange-100 text-orange-800 dark:bg-orange-900/20 dark:text-orange-400";
      default: return "bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-400";
    }
  };

  const isNotificationRead = (notification: Notification) => {
    return notification.isRead[userProfile?.uid || ""] || false;
  };

  const filteredNotifications = notifications.filter(notification => {
    switch (activeTab) {
      case "unread": return !isNotificationRead(notification);
      case "announcements": return notification.type === "announcement";
      case "system": return notification.type === "system";
      default: return true;
    }
  });

  const handleCreateNotification = async () => {
    if (!newNotification.title || !newNotification.message) {
      toast({
        title: "Error",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    try {
      await addFirestoreDocument("notifications", {
        ...newNotification,
        notificationId: `notif_${Date.now()}`,
      });

      toast({
        title: "Success",
        description: "Notification created successfully!",
      });

      setIsCreateOpen(false);
      setNewNotification({
        title: "",
        message: "",
        targetUsers: ["all"],
        targetRoles: [],
        type: "announcement",
        priority: "medium",
        isRead: {},
      });
    } catch (error) {
      console.error("Create notification error:", error);
      toast({
        title: "Error",
        description: "Failed to create notification.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleMarkAsRead = async (notificationId: string) => {
    if (!userProfile) return;

    try {
      const notification = notifications.find(n => n.notificationId === notificationId);
      if (!notification) return;

      const updatedIsRead = {
        ...notification.isRead,
        [userProfile.uid]: true,
      };

      await updateFirestoreDocument("notifications", notificationId, {
        isRead: updatedIsRead,
      });
    } catch (error) {
      console.error("Mark as read error:", error);
    }
  };

  const handleTargetUsersChange = (targetType: string, checked: boolean) => {
    if (targetType === "all") {
      if (checked) {
        setNewNotification(prev => ({ ...prev, targetUsers: ["all"], targetRoles: [] }));
      } else {
        setNewNotification(prev => ({ ...prev, targetUsers: [] }));
      }
    } else if (targetType === "employees" || targetType === "contractors") {
      const role = targetType === "employees" ? "employee" : "contractor";
      if (checked) {
        setNewNotification(prev => ({
          ...prev,
          targetUsers: prev.targetUsers.filter(u => u !== "all"),
          targetRoles: [...(prev.targetRoles || []), role],
        }));
      } else {
        setNewNotification(prev => ({
          ...prev,
          targetRoles: (prev.targetRoles || []).filter(r => r !== role),
        }));
      }
    }
  };

  const unreadCount = notifications.filter(n => !isNotificationRead(n)).length;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
            {userProfile?.role === "admin" ? "Notification Management" : "Announcements"}
          </h1>
          {unreadCount > 0 && (
            <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
              You have {unreadCount} unread notification(s)
            </p>
          )}
        </div>
        
        {userProfile?.role === "admin" && (
          <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
            <DialogTrigger asChild>
              <Button className="bg-primary hover:bg-blue-700" data-testid="button-create-notification">
                <i className="fas fa-plus mr-2"></i>
                Create Notification
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>Create New Notification</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="title">Title *</Label>
                  <Input
                    id="title"
                    value={newNotification.title}
                    onChange={(e) => setNewNotification(prev => ({ ...prev, title: e.target.value }))}
                    placeholder="Enter notification title"
                    data-testid="input-notification-title"
                  />
                </div>
                
                <div>
                  <Label htmlFor="message">Message *</Label>
                  <Textarea
                    id="message"
                    value={newNotification.message}
                    onChange={(e) => setNewNotification(prev => ({ ...prev, message: e.target.value }))}
                    placeholder="Enter notification message"
                    rows={4}
                    data-testid="textarea-notification-message"
                  />
                </div>

                <div>
                  <Label>Target Audience</Label>
                  <div className="space-y-2 mt-2">
                    <label className="flex items-center space-x-2">
                      <Checkbox
                        checked={newNotification.targetUsers.includes("all")}
                        onCheckedChange={(checked) => handleTargetUsersChange("all", checked as boolean)}
                        data-testid="checkbox-target-all"
                      />
                      <span className="text-sm">All Users</span>
                    </label>
                    
                    <label className="flex items-center space-x-2">
                      <Checkbox
                        checked={newNotification.targetRoles?.includes("employee") || false}
                        onCheckedChange={(checked) => handleTargetUsersChange("employees", checked as boolean)}
                        disabled={newNotification.targetUsers.includes("all")}
                        data-testid="checkbox-target-employees"
                      />
                      <span className="text-sm">Employees Only</span>
                    </label>
                    
                    <label className="flex items-center space-x-2">
                      <Checkbox
                        checked={newNotification.targetRoles?.includes("contractor") || false}
                        onCheckedChange={(checked) => handleTargetUsersChange("contractors", checked as boolean)}
                        disabled={newNotification.targetUsers.includes("all")}
                        data-testid="checkbox-target-contractors"
                      />
                      <span className="text-sm">Contractors Only</span>
                    </label>
                  </div>
                </div>

                <div>
                  <Label htmlFor="type">Type</Label>
                  <Select
                    value={newNotification.type}
                    onValueChange={(value) => setNewNotification(prev => ({ ...prev, type: value as Notification["type"] }))}
                  >
                    <SelectTrigger data-testid="select-notification-type">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="announcement">Announcement</SelectItem>
                      <SelectItem value="system">System</SelectItem>
                      <SelectItem value="reminder">Reminder</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="priority">Priority</Label>
                  <Select
                    value={newNotification.priority}
                    onValueChange={(value) => setNewNotification(prev => ({ ...prev, priority: value as Notification["priority"] }))}
                  >
                    <SelectTrigger data-testid="select-notification-priority">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="flex space-x-2 pt-4">
                  <Button
                    onClick={handleCreateNotification}
                    disabled={loading}
                    className="flex-1 bg-primary hover:bg-blue-700"
                    data-testid="button-save-notification"
                  >
                    {loading ? (
                      <>
                        <i className="fas fa-spinner fa-spin mr-2"></i>
                        Creating...
                      </>
                    ) : (
                      "Create Notification"
                    )}
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => setIsCreateOpen(false)}
                    disabled={loading}
                    data-testid="button-cancel-notification"
                  >
                    Cancel
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        )}
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="all" data-testid="tab-all-notifications">
            All ({notifications.length})
          </TabsTrigger>
          <TabsTrigger value="unread" data-testid="tab-unread-notifications">
            Unread ({unreadCount})
          </TabsTrigger>
          <TabsTrigger value="announcements" data-testid="tab-announcement-notifications">
            Announcements ({notifications.filter(n => n.type === "announcement").length})
          </TabsTrigger>
          <TabsTrigger value="system" data-testid="tab-system-notifications">
            System ({notifications.filter(n => n.type === "system").length})
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value={activeTab} className="space-y-4">
          {filteredNotifications.length > 0 ? (
            <div className="space-y-4">
              {filteredNotifications.map((notification) => {
                const isRead = isNotificationRead(notification);
                
                return (
                  <Card 
                    key={notification.notificationId} 
                    className={`bg-white dark:bg-dark-card border dark:border-dark-border ${
                      !isRead ? 'border-l-4 border-l-primary' : ''
                    }`}
                    data-testid={`card-notification-${notification.notificationId}`}
                  >
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center space-x-2 mb-2">
                            <CardTitle className={`text-lg ${!isRead ? 'font-bold' : 'font-medium'} text-gray-900 dark:text-white`}>
                              {notification.title}
                            </CardTitle>
                            {!isRead && (
                              <div className="w-2 h-2 bg-primary rounded-full"></div>
                            )}
                          </div>
                          <div className="flex items-center space-x-2">
                            <Badge className={getTypeColor(notification.type)}>
                              {notification.type}
                            </Badge>
                            <Badge className={getPriorityColor(notification.priority)}>
                              {notification.priority}
                            </Badge>
                            <span className="text-sm text-gray-500 dark:text-gray-400">
                              {formatDisplayDate(notification.createdAt)}
                            </span>
                          </div>
                        </div>
                        {!isRead && userProfile?.role !== "admin" && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleMarkAsRead(notification.notificationId!)}
                            data-testid={`button-mark-read-${notification.notificationId}`}
                          >
                            <i className="fas fa-check text-xs"></i>
                          </Button>
                        )}
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-gray-700 dark:text-gray-300 whitespace-pre-wrap">
                        {notification.message}
                      </p>
                      
                      {notification.expiresAt && (
                        <div className="mt-3 p-2 bg-yellow-50 dark:bg-yellow-900/20 rounded border border-yellow-200 dark:border-yellow-800">
                          <p className="text-xs text-yellow-700 dark:text-yellow-400">
                            <i className="fas fa-clock mr-1"></i>
                            Expires on {formatDisplayDate(notification.expiresAt)}
                          </p>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          ) : (
            <Card className="bg-white dark:bg-dark-card border dark:border-dark-border">
              <CardContent className="text-center py-8">
                <i className="fas fa-bell text-4xl text-gray-400 mb-4"></i>
                <p className="text-gray-500 dark:text-gray-400">
                  No notifications found for the selected filter.
                </p>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
