import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useFirestoreCollection, addFirestoreDocument } from "@/hooks/useFirestore";
import { User, Attendance, Invoice } from "@shared/schema";
import { where } from "firebase/firestore";
import { useToast } from "@/hooks/use-toast";

interface InvoiceGeneratorProps {
  onClose: () => void;
}

export function InvoiceGenerator({ onClose }: InvoiceGeneratorProps) {
  const { toast } = useToast();
  const [selectedMonth, setSelectedMonth] = useState(new Date().getMonth());
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());
  const [selectedUsers, setSelectedUsers] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);

  const { data: users } = useFirestoreCollection<User>("users");
  const { data: attendance } = useFirestoreCollection<Attendance>("attendance");

  const months = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
  ];

  const eligibleUsers = users.filter(u => u.role !== "admin" && u.isActive);

  const calculateInvoiceAmount = (user: User) => {
    const monthString = String(selectedMonth + 1).padStart(2, '0');
    const yearString = selectedYear.toString();
    
    // Get attendance records for the selected month/year
    const userAttendance = attendance.filter(a => 
      a.userId === user.uid && 
      a.date.startsWith(`${yearString}-${monthString}`)
    );

    let baseSalary = 0;
    let contractRate = 0;
    let overtimeHours = 0;
    let overtimeAmount = 0;

    if (user.role === "employee") {
      baseSalary = user.salary || 0;
    } else if (user.role === "contractor") {
      // Calculate total hours for contractor
      const totalHours = userAttendance.reduce((sum, a) => sum + a.totalHours, 0);
      contractRate = totalHours * (user.contractRate || 0);
    }

    // Calculate overtime
    overtimeHours = userAttendance.reduce((sum, a) => sum + a.overtimeHours, 0);
    overtimeAmount = overtimeHours * (user.overtimeRate || 0);

    const total = baseSalary + contractRate + overtimeAmount;

    return {
      baseSalary,
      contractRate,
      overtimeHours,
      overtimeAmount,
      total,
      attendanceDays: userAttendance.filter(a => a.status === "present").length
    };
  };

  const handleUserSelection = (userId: string, checked: boolean) => {
    if (checked) {
      setSelectedUsers(prev => [...prev, userId]);
    } else {
      setSelectedUsers(prev => prev.filter(id => id !== userId));
    }
  };

  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      setSelectedUsers(eligibleUsers.map(u => u.uid));
    } else {
      setSelectedUsers([]);
    }
  };

  const handleGenerateInvoices = async () => {
    if (selectedUsers.length === 0) {
      toast({
        title: "Error",
        description: "Please select at least one user to generate invoices.",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    try {
      const invoicePromises = selectedUsers.map(async (userId) => {
        const user = users.find(u => u.uid === userId)!;
        const calculation = calculateInvoiceAmount(user);

        const invoiceData: Partial<Invoice> = {
          invoiceId: `inv_${Date.now()}_${userId.slice(-4)}`,
          userId,
          role: user.role,
          month: months[selectedMonth],
          year: selectedYear,
          breakdown: {
            baseSalary: user.role === "employee" ? calculation.baseSalary : undefined,
            contractRate: user.role === "contractor" ? calculation.contractRate : undefined,
            overtimeHours: calculation.overtimeHours,
            overtimeAmount: calculation.overtimeAmount,
            bonuses: 0,
            deductions: 0,
          },
          total: calculation.total,
          status: "draft" as const,
        };

        return addFirestoreDocument("invoices", invoiceData);
      });

      await Promise.all(invoicePromises);

      toast({
        title: "Success",
        description: `Generated ${selectedUsers.length} invoice(s) successfully!`,
      });

      onClose();
    } catch (error) {
      console.error("Generate invoices error:", error);
      toast({
        title: "Error",
        description: "Failed to generate invoices.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Month/Year Selection */}
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="month">Month</Label>
          <Select value={selectedMonth.toString()} onValueChange={(value) => setSelectedMonth(parseInt(value))}>
            <SelectTrigger data-testid="select-invoice-month">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {months.map((month, index) => (
                <SelectItem key={index} value={index.toString()}>
                  {month}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div>
          <Label htmlFor="year">Year</Label>
          <Input
            id="year"
            type="number"
            value={selectedYear}
            onChange={(e) => setSelectedYear(parseInt(e.target.value))}
            min="2020"
            max="2030"
            data-testid="input-invoice-year"
          />
        </div>
      </div>

      {/* User Selection */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <Label>Select Users</Label>
          <div className="flex items-center space-x-2">
            <Checkbox
              id="select-all"
              checked={selectedUsers.length === eligibleUsers.length}
              onCheckedChange={handleSelectAll}
              data-testid="checkbox-select-all-users"
            />
            <Label htmlFor="select-all" className="text-sm">
              Select All ({eligibleUsers.length})
            </Label>
          </div>
        </div>

        <div className="border rounded-lg max-h-64 overflow-y-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-12"></TableHead>
                <TableHead>Name</TableHead>
                <TableHead>Role</TableHead>
                <TableHead>Rate</TableHead>
                <TableHead>Attendance</TableHead>
                <TableHead>Estimated Amount</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {eligibleUsers.map((user) => {
                const calculation = calculateInvoiceAmount(user);
                const isSelected = selectedUsers.includes(user.uid);

                return (
                  <TableRow key={user.uid} data-testid={`row-user-invoice-${user.uid}`}>
                    <TableCell>
                      <Checkbox
                        checked={isSelected}
                        onCheckedChange={(checked) => handleUserSelection(user.uid, checked as boolean)}
                        data-testid={`checkbox-user-${user.uid}`}
                      />
                    </TableCell>
                    <TableCell className="font-medium">{user.name}</TableCell>
                    <TableCell className="capitalize">{user.role}</TableCell>
                    <TableCell>
                      {user.role === "employee" 
                        ? `$${user.salary?.toLocaleString()}/month`
                        : `$${user.contractRate}/hour`
                      }
                    </TableCell>
                    <TableCell>{calculation.attendanceDays} days</TableCell>
                    <TableCell className="font-bold">
                      ${calculation.total.toLocaleString()}
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
      </div>

      {/* Summary */}
      {selectedUsers.length > 0 && (
        <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
          <h4 className="font-medium text-blue-900 dark:text-blue-100 mb-2">
            Generation Summary
          </h4>
          <div className="text-sm text-blue-700 dark:text-blue-300">
            <p>Selected Users: {selectedUsers.length}</p>
            <p>Period: {months[selectedMonth]} {selectedYear}</p>
            <p>
              Total Amount: $
              {selectedUsers
                .reduce((sum, userId) => {
                  const user = users.find(u => u.uid === userId)!;
                  return sum + calculateInvoiceAmount(user).total;
                }, 0)
                .toLocaleString()}
            </p>
          </div>
        </div>
      )}

      {/* Actions */}
      <div className="flex space-x-2">
        <Button
          onClick={handleGenerateInvoices}
          disabled={loading || selectedUsers.length === 0}
          className="flex-1 bg-primary hover:bg-blue-700"
          data-testid="button-generate-selected-invoices"
        >
          {loading ? (
            <>
              <i className="fas fa-spinner fa-spin mr-2"></i>
              Generating...
            </>
          ) : (
            <>
              <i className="fas fa-file-invoice mr-2"></i>
              Generate {selectedUsers.length} Invoice(s)
            </>
          )}
        </Button>
        <Button
          variant="outline"
          onClick={onClose}
          disabled={loading}
          data-testid="button-cancel-invoice-generation"
        >
          Cancel
        </Button>
      </div>
    </div>
  );
}
