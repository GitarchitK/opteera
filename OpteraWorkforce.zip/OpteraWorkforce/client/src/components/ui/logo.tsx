import { cn } from "@/lib/utils";

interface LogoProps {
  className?: string;
  showText?: boolean;
  size?: "sm" | "md" | "lg";
}

export function Logo({ className, showText = true, size = "md" }: LogoProps) {
  const sizeClasses = {
    sm: "w-8 h-8",
    md: "w-10 h-10", 
    lg: "w-12 h-12"
  };

  const textSizeClasses = {
    sm: "text-lg",
    md: "text-xl",
    lg: "text-2xl"
  };

  return (
    <div className={cn("flex items-center space-x-3", className)}>
      <div className={cn(
        "bg-gradient-to-br from-primary to-blue-600 rounded-lg flex items-center justify-center",
        sizeClasses[size]
      )}>
        <svg 
          className="text-white" 
          width="60%" 
          height="60%" 
          viewBox="0 0 24 24" 
          fill="currentColor"
        >
          <path d="M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5zM12 17c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5zm0-8c-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3-1.34-3-3-3z"/>
        </svg>
      </div>
      {showText && (
        <div>
          <h1 className={cn("font-bold text-gray-900 dark:text-white", textSizeClasses[size])}>
            Optera
          </h1>
          <p className="text-xs text-gray-500 dark:text-gray-400">Workforce Management</p>
        </div>
      )}
    </div>
  );
}
