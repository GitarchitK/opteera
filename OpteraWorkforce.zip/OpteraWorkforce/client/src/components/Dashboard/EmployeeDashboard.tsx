import { useAuth } from "@/hooks/useAuth";
import { useFirestoreCollection } from "@/hooks/useFirestore";
import { Project, Task, Attendance, Leave } from "@shared/schema";
import { where } from "firebase/firestore";
import { formatDateString } from "@/utils/dateHelpers";
import { DateTimeWidget } from "./DateTimeWidget";
import { StatsCard } from "./StatsCard";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

export function EmployeeDashboard() {
  const { userProfile } = useAuth();
  
  if (!userProfile) return null;

  const { data: assignedProjects } = useFirestoreCollection<Project>(
    "projects",
    [where("assignedEmployees", "array-contains", userProfile.uid)]
  );

  const { data: assignedTasks } = useFirestoreCollection<Task>(
    "tasks",
    [where("assignedTo", "==", userProfile.uid)]
  );

  const { data: myAttendance } = useFirestoreCollection<Attendance>(
    "attendance",
    [where("userId", "==", userProfile.uid)]
  );

  const { data: myLeaves } = useFirestoreCollection<Leave>(
    "leaves",
    [where("userId", "==", userProfile.uid)]
  );

  // Calculate employee-specific stats
  const stats = {
    assignedProjects: assignedProjects.length,
    pendingTasks: assignedTasks.filter(t => t.status !== "completed").length,
    completedTasks: assignedTasks.filter(t => t.status === "completed").length,
    pendingLeaves: myLeaves.filter(l => l.status === "pending").length,
  };

  const todaysAttendance = myAttendance.find(a => a.date === formatDateString(new Date()));

  return (
    <div className="space-y-6">
      {/* Greeting & Date Time */}
      <DateTimeWidget />

      {/* Employee Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatsCard
          title="Assigned Projects"
          value={stats.assignedProjects}
          icon={<i className="fas fa-project-diagram text-blue-600 dark:text-blue-400 text-xl"></i>}
          iconBgColor="bg-blue-100 dark:bg-blue-900/30"
          testId="text-assigned-projects"
        />
        
        <StatsCard
          title="Pending Tasks"
          value={stats.pendingTasks}
          icon={<i className="fas fa-tasks text-orange-600 dark:text-orange-400 text-xl"></i>}
          iconBgColor="bg-orange-100 dark:bg-orange-900/30"
          testId="text-pending-tasks"
        />
        
        <StatsCard
          title="Completed Tasks"
          value={stats.completedTasks}
          icon={<i className="fas fa-check-circle text-green-600 dark:text-green-400 text-xl"></i>}
          iconBgColor="bg-green-100 dark:bg-green-900/30"
          testId="text-completed-tasks"
        />
        
        <StatsCard
          title="Leave Requests"
          value={stats.pendingLeaves}
          icon={<i className="fas fa-calendar-alt text-purple-600 dark:text-purple-400 text-xl"></i>}
          iconBgColor="bg-purple-100 dark:bg-purple-900/30"
          testId="text-leave-requests"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Today's Attendance */}
        <Card className="bg-white dark:bg-dark-card border dark:border-dark-border">
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
              Today's Attendance
            </h3>
            
            {todaysAttendance ? (
              <div className="space-y-4">
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600 dark:text-gray-400">Status:</span>
                  <Badge variant="secondary" className={
                    todaysAttendance.status === "present" ? "bg-green-100 text-green-800" :
                    todaysAttendance.status === "absent" ? "bg-red-100 text-red-800" :
                    "bg-yellow-100 text-yellow-800"
                  }>
                    {todaysAttendance.status}
                  </Badge>
                </div>
                
                {todaysAttendance.checkInTime && (
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600 dark:text-gray-400">Check In:</span>
                    <span className="text-sm font-medium">
                      {todaysAttendance.checkInTime.toLocaleTimeString()}
                    </span>
                  </div>
                )}
                
                {todaysAttendance.checkOutTime && (
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600 dark:text-gray-400">Check Out:</span>
                    <span className="text-sm font-medium">
                      {todaysAttendance.checkOutTime.toLocaleTimeString()}
                    </span>
                  </div>
                )}
                
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600 dark:text-gray-400">Total Hours:</span>
                  <span className="text-sm font-medium">{todaysAttendance.totalHours.toFixed(2)}</span>
                </div>
              </div>
            ) : (
              <div className="text-center py-4">
                <p className="text-gray-500 dark:text-gray-400 mb-4">No attendance recorded today</p>
                <Button className="w-full" data-testid="button-clock-in">
                  Clock In
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Recent Tasks */}
        <Card className="lg:col-span-2 bg-white dark:bg-dark-card border dark:border-dark-border">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                Recent Tasks
              </h3>
              <Button variant="ghost" className="text-primary hover:text-blue-700 text-sm">
                View All
              </Button>
            </div>
            
            <div className="space-y-3">
              {assignedTasks.slice(0, 5).map((task) => (
                <div
                  key={task.taskId}
                  className="flex items-center justify-between p-3 border border-gray-200 dark:border-dark-border rounded-lg"
                  data-testid={`card-task-${task.taskId}`}
                >
                  <div>
                    <p className="font-medium text-gray-900 dark:text-white">
                      {task.title}
                    </p>
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      Due: {task.deadline.toLocaleDateString()}
                    </p>
                  </div>
                  <Badge variant="secondary" className={
                    task.status === "completed" ? "bg-green-100 text-green-800" :
                    task.status === "in-progress" ? "bg-blue-100 text-blue-800" :
                    "bg-gray-100 text-gray-800"
                  }>
                    {task.status}
                  </Badge>
                </div>
              ))}
              
              {assignedTasks.length === 0 && (
                <div className="text-center py-8 text-gray-500 dark:text-gray-400">
                  <p>No tasks assigned</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
