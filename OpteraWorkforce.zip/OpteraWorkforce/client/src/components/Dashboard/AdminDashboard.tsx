import { useFirestoreCollection } from "@/hooks/useFirestore";
import { User, Project, Task, Attendance, Leave } from "@shared/schema";
import { where } from "firebase/firestore";
import { formatDateString } from "@/utils/dateHelpers";
import { DateTimeWidget } from "./DateTimeWidget";
import { StatsCard } from "./StatsCard";
import { AttendanceWidget } from "./AttendanceWidget";
import { LeaveRequestsWidget } from "./LeaveRequestsWidget";
import { ProjectsWidget } from "./ProjectsWidget";
import { QuickActionsWidget } from "./QuickActionsWidget";

export function AdminDashboard() {
  const { data: users } = useFirestoreCollection<User>("users");
  const { data: projects } = useFirestoreCollection<Project>("projects");
  const { data: tasks } = useFirestoreCollection<Task>("tasks");
  const { data: todayAttendance } = useFirestoreCollection<Attendance>(
    "attendance",
    [where("date", "==", formatDateString(new Date()))]
  );
  const { data: pendingLeaves } = useFirestoreCollection<Leave>(
    "leaves",
    [where("status", "==", "pending")]
  );

  // Calculate stats
  const stats = {
    totalEmployees: users.filter(u => u.role === "employee").length,
    activeContractors: users.filter(u => u.role === "contractor").length,
    activeProjects: projects.filter(p => p.status === "active").length,
    pendingTasks: tasks.filter(t => t.status !== "completed").length,
  };

  const overdueTasksCount = tasks.filter(task => 
    task.status !== "completed" && new Date() > task.deadline
  ).length;

  return (
    <div className="space-y-6">
      {/* Date & Time Widget */}
      <DateTimeWidget />

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatsCard
          title="Total Employees"
          value={stats.totalEmployees}
          change="+2 this month"
          changeType="increase"
          icon={<i className="fas fa-users text-blue-600 dark:text-blue-400 text-xl"></i>}
          iconBgColor="bg-blue-100 dark:bg-blue-900/30"
          testId="text-total-employees"
        />
        
        <StatsCard
          title="Active Contractors"
          value={stats.activeContractors}
          change="+1 this week"
          changeType="increase"
          icon={<i className="fas fa-handshake text-orange-600 dark:text-orange-400 text-xl"></i>}
          iconBgColor="bg-orange-100 dark:bg-orange-900/30"
          testId="text-active-contractors"
        />
        
        <StatsCard
          title="Active Projects"
          value={stats.activeProjects}
          change="3 due this week"
          changeType="neutral"
          icon={<i className="fas fa-project-diagram text-green-600 dark:text-green-400 text-xl"></i>}
          iconBgColor="bg-green-100 dark:bg-green-900/30"
          testId="text-active-projects"
        />
        
        <StatsCard
          title="Pending Tasks"
          value={stats.pendingTasks}
          change={`${overdueTasksCount} overdue`}
          changeType="decrease"
          icon={<i className="fas fa-tasks text-red-600 dark:text-red-400 text-xl"></i>}
          iconBgColor="bg-red-100 dark:bg-red-900/30"
          testId="text-pending-tasks"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Attendance Summary */}
        <AttendanceWidget />

        {/* Pending Leave Requests */}
        <LeaveRequestsWidget />
      </div>

      {/* Recent Projects & Quick Actions */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <ProjectsWidget />
        <QuickActionsWidget />
      </div>
    </div>
  );
}
