import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { useAuth } from "@/hooks/useAuth";
import { useFirestoreCollection, addFirestoreDocument, updateFirestoreDocument } from "@/hooks/useFirestore";
import { Project, User, Task, InsertProject } from "@shared/schema";
import { where } from "firebase/firestore";
import { formatDisplayDate } from "@/utils/dateHelpers";
import { useToast } from "@/hooks/use-toast";

export function ProjectManagement() {
  const { userProfile } = useAuth();
  const { toast } = useToast();
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [loading, setLoading] = useState(false);

  const { data: allProjects } = useFirestoreCollection<Project>("projects");
  const { data: users } = useFirestoreCollection<User>("users");
  const { data: allTasks } = useFirestoreCollection<Task>("tasks");

  // Filter projects based on user role
  const projects = userProfile?.role === "admin" 
    ? allProjects
    : allProjects.filter(p => 
        p.assignedEmployees.includes(userProfile?.uid || "") ||
        p.assignedContractors.includes(userProfile?.uid || "")
      );

  const [newProject, setNewProject] = useState<InsertProject>({
    name: "",
    description: "",
    assignedEmployees: [],
    assignedContractors: [],
    status: "active",
    startDate: new Date(),
  });

  const employees = users.filter(u => u.role === "employee");
  const contractors = users.filter(u => u.role === "contractor");

  const getProjectProgress = (projectId: string) => {
    const projectTasks = allTasks.filter(task => task.projectId === projectId);
    if (projectTasks.length === 0) return 0;
    
    const completedTasks = projectTasks.filter(task => task.status === "completed");
    return Math.round((completedTasks.length / projectTasks.length) * 100);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active": return "bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400";
      case "completed": return "bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-400";
      case "on-hold": return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-400";
      case "cancelled": return "bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-400";
      default: return "bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-400";
    }
  };

  const handleCreateProject = async () => {
    if (!newProject.name || !newProject.description) {
      toast({
        title: "Error",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    try {
      await addFirestoreDocument("projects", {
        ...newProject,
        projectId: `proj_${Date.now()}`,
      });

      toast({
        title: "Success",
        description: "Project created successfully!",
      });

      setIsCreateOpen(false);
      setNewProject({
        name: "",
        description: "",
        assignedEmployees: [],
        assignedContractors: [],
        status: "active",
        startDate: new Date(),
      });
    } catch (error) {
      console.error("Create project error:", error);
      toast({
        title: "Error",
        description: "Failed to create project.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateStatus = async (projectId: string, newStatus: Project["status"]) => {
    try {
      await updateFirestoreDocument("projects", projectId, { status: newStatus });
      toast({
        title: "Success",
        description: "Project status updated successfully.",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update project status.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
          {userProfile?.role === "admin" ? "Project Management" : "My Projects"}
        </h1>
        
        {userProfile?.role === "admin" && (
          <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
            <DialogTrigger asChild>
              <Button className="bg-primary hover:bg-blue-700" data-testid="button-create-project">
                <i className="fas fa-plus mr-2"></i>
                Create Project
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>Create New Project</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="name">Project Name *</Label>
                  <Input
                    id="name"
                    value={newProject.name}
                    onChange={(e) => setNewProject(prev => ({ ...prev, name: e.target.value }))}
                    placeholder="Enter project name"
                    data-testid="input-project-name"
                  />
                </div>
                
                <div>
                  <Label htmlFor="description">Description *</Label>
                  <Textarea
                    id="description"
                    value={newProject.description}
                    onChange={(e) => setNewProject(prev => ({ ...prev, description: e.target.value }))}
                    placeholder="Enter project description"
                    rows={3}
                    data-testid="textarea-project-description"
                  />
                </div>

                <div>
                  <Label>Assign Employees</Label>
                  <div className="space-y-2 max-h-32 overflow-y-auto">
                    {employees.map((employee) => (
                      <label key={employee.uid} className="flex items-center space-x-2">
                        <input
                          type="checkbox"
                          checked={newProject.assignedEmployees.includes(employee.uid)}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setNewProject(prev => ({
                                ...prev,
                                assignedEmployees: [...prev.assignedEmployees, employee.uid]
                              }));
                            } else {
                              setNewProject(prev => ({
                                ...prev,
                                assignedEmployees: prev.assignedEmployees.filter(id => id !== employee.uid)
                              }));
                            }
                          }}
                          data-testid={`checkbox-employee-${employee.uid}`}
                        />
                        <span className="text-sm">{employee.name}</span>
                      </label>
                    ))}
                  </div>
                </div>

                <div>
                  <Label>Assign Contractors</Label>
                  <div className="space-y-2 max-h-32 overflow-y-auto">
                    {contractors.map((contractor) => (
                      <label key={contractor.uid} className="flex items-center space-x-2">
                        <input
                          type="checkbox"
                          checked={newProject.assignedContractors.includes(contractor.uid)}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setNewProject(prev => ({
                                ...prev,
                                assignedContractors: [...prev.assignedContractors, contractor.uid]
                              }));
                            } else {
                              setNewProject(prev => ({
                                ...prev,
                                assignedContractors: prev.assignedContractors.filter(id => id !== contractor.uid)
                              }));
                            }
                          }}
                          data-testid={`checkbox-contractor-${contractor.uid}`}
                        />
                        <span className="text-sm">{contractor.name}</span>
                      </label>
                    ))}
                  </div>
                </div>
                
                <div className="flex space-x-2 pt-4">
                  <Button
                    onClick={handleCreateProject}
                    disabled={loading}
                    className="flex-1 bg-primary hover:bg-blue-700"
                    data-testid="button-save-project"
                  >
                    {loading ? (
                      <>
                        <i className="fas fa-spinner fa-spin mr-2"></i>
                        Creating...
                      </>
                    ) : (
                      "Create Project"
                    )}
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => setIsCreateOpen(false)}
                    disabled={loading}
                    data-testid="button-cancel-project"
                  >
                    Cancel
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {projects.map((project) => {
          const progress = getProjectProgress(project.projectId);
          const totalMembers = project.assignedEmployees.length + project.assignedContractors.length;
          
          return (
            <Card key={project.projectId} className="bg-white dark:bg-dark-card border dark:border-dark-border" data-testid={`card-project-${project.projectId}`}>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <CardTitle className="text-lg text-gray-900 dark:text-white">
                      {project.name}
                    </CardTitle>
                    <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                      {project.description}
                    </p>
                  </div>
                  <Badge className={getStatusColor(project.status)}>
                    {project.status}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span className="text-gray-600 dark:text-gray-400">Progress</span>
                    <span className="font-medium">{progress}%</span>
                  </div>
                  <Progress value={progress} className="h-2" />
                </div>
                
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-600 dark:text-gray-400">Team Size:</span>
                    <span className="font-medium">{totalMembers} members</span>
                  </div>
                  
                  <div className="flex justify-between">
                    <span className="text-gray-600 dark:text-gray-400">Started:</span>
                    <span className="font-medium">{formatDisplayDate(project.startDate)}</span>
                  </div>
                  
                  {project.endDate && (
                    <div className="flex justify-between">
                      <span className="text-gray-600 dark:text-gray-400">Due:</span>
                      <span className="font-medium">{formatDisplayDate(project.endDate)}</span>
                    </div>
                  )}
                </div>

                {userProfile?.role === "admin" && (
                  <div className="pt-2 border-t border-gray-200 dark:border-gray-700">
                    <Select
                      value={project.status}
                      onValueChange={(value) => handleUpdateStatus(project.projectId!, value as Project["status"])}
                    >
                      <SelectTrigger className="w-full" data-testid={`select-project-status-${project.projectId}`}>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="active">Active</SelectItem>
                        <SelectItem value="completed">Completed</SelectItem>
                        <SelectItem value="on-hold">On Hold</SelectItem>
                        <SelectItem value="cancelled">Cancelled</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>

      {projects.length === 0 && (
        <Card className="bg-white dark:bg-dark-card border dark:border-dark-border">
          <CardContent className="text-center py-8">
            <i className="fas fa-project-diagram text-4xl text-gray-400 mb-4"></i>
            <p className="text-gray-500 dark:text-gray-400">
              {userProfile?.role === "admin" 
                ? "No projects created yet. Create your first project to get started."
                : "You haven't been assigned to any projects yet."
              }
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
