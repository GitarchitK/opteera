import { useAuth } from "@/hooks/useAuth";
import { useFirestoreCollection } from "@/hooks/useFirestore";
import { Project, Task, Attendance, Invoice } from "@shared/schema";
import { where } from "firebase/firestore";
import { formatDateString } from "@/utils/dateHelpers";
import { DateTimeWidget } from "./DateTimeWidget";
import { StatsCard } from "./StatsCard";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

export function ContractorDashboard() {
  const { userProfile } = useAuth();
  
  if (!userProfile) return null;

  const { data: assignedProjects } = useFirestoreCollection<Project>(
    "projects",
    [where("assignedContractors", "array-contains", userProfile.uid)]
  );

  const { data: assignedTasks } = useFirestoreCollection<Task>(
    "tasks",
    [where("assignedTo", "==", userProfile.uid)]
  );

  const { data: myAttendance } = useFirestoreCollection<Attendance>(
    "attendance",
    [where("userId", "==", userProfile.uid)]
  );

  const { data: myInvoices } = useFirestoreCollection<Invoice>(
    "invoices",
    [where("userId", "==", userProfile.uid)]
  );

  // Calculate contractor-specific stats
  const stats = {
    activeProjects: assignedProjects.filter(p => p.status === "active").length,
    pendingTasks: assignedTasks.filter(t => t.status !== "completed").length,
    completedTasks: assignedTasks.filter(t => t.status === "completed").length,
    totalInvoices: myInvoices.length,
  };

  const todaysAttendance = myAttendance.find(a => a.date === formatDateString(new Date()));
  const thisMonthsInvoice = myInvoices.find(inv => 
    inv.month === new Date().toLocaleDateString('en-US', { month: 'long' }) &&
    inv.year === new Date().getFullYear()
  );

  return (
    <div className="space-y-6">
      {/* Greeting & Date Time */}
      <DateTimeWidget />

      {/* Contractor Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatsCard
          title="Active Projects"
          value={stats.activeProjects}
          icon={<i className="fas fa-project-diagram text-blue-600 dark:text-blue-400 text-xl"></i>}
          iconBgColor="bg-blue-100 dark:bg-blue-900/30"
          testId="text-active-projects"
        />
        
        <StatsCard
          title="Pending Tasks"
          value={stats.pendingTasks}
          icon={<i className="fas fa-tasks text-orange-600 dark:text-orange-400 text-xl"></i>}
          iconBgColor="bg-orange-100 dark:bg-orange-900/30"
          testId="text-pending-tasks"
        />
        
        <StatsCard
          title="Completed Tasks"
          value={stats.completedTasks}
          icon={<i className="fas fa-check-circle text-green-600 dark:text-green-400 text-xl"></i>}
          iconBgColor="bg-green-100 dark:bg-green-900/30"
          testId="text-completed-tasks"
        />
        
        <StatsCard
          title="Contract Rate"
          value={`$${userProfile.contractRate || 0}/hr`}
          icon={<i className="fas fa-dollar-sign text-purple-600 dark:text-purple-400 text-xl"></i>}
          iconBgColor="bg-purple-100 dark:bg-purple-900/30"
          testId="text-contract-rate"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Time Tracking */}
        <Card className="bg-white dark:bg-dark-card border dark:border-dark-border">
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
              Time Tracking
            </h3>
            
            {todaysAttendance ? (
              <div className="space-y-4">
                {todaysAttendance.checkInTime && (
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600 dark:text-gray-400">Started:</span>
                    <span className="text-sm font-medium">
                      {todaysAttendance.checkInTime.toLocaleTimeString()}
                    </span>
                  </div>
                )}
                
                {todaysAttendance.checkOutTime && (
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600 dark:text-gray-400">Ended:</span>
                    <span className="text-sm font-medium">
                      {todaysAttendance.checkOutTime.toLocaleTimeString()}
                    </span>
                  </div>
                )}
                
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600 dark:text-gray-400">Total Hours:</span>
                  <span className="text-sm font-medium">{todaysAttendance.totalHours.toFixed(2)}</span>
                </div>
                
                {todaysAttendance.overtimeHours > 0 && (
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600 dark:text-gray-400">Overtime:</span>
                    <span className="text-sm font-medium text-orange-600">
                      {todaysAttendance.overtimeHours.toFixed(2)} hrs
                    </span>
                  </div>
                )}
              </div>
            ) : (
              <div className="text-center py-4">
                <p className="text-gray-500 dark:text-gray-400 mb-4">No time logged today</p>
                <Button className="w-full" data-testid="button-start-timer">
                  Start Timer
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Current Month Invoice */}
        <Card className="bg-white dark:bg-dark-card border dark:border-dark-border">
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
              This Month's Invoice
            </h3>
            
            {thisMonthsInvoice ? (
              <div className="space-y-4">
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600 dark:text-gray-400">Status:</span>
                  <Badge variant="secondary" className={
                    thisMonthsInvoice.status === "paid" ? "bg-green-100 text-green-800" :
                    thisMonthsInvoice.status === "sent" ? "bg-blue-100 text-blue-800" :
                    "bg-gray-100 text-gray-800"
                  }>
                    {thisMonthsInvoice.status}
                  </Badge>
                </div>
                
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600 dark:text-gray-400">Total Amount:</span>
                  <span className="text-lg font-bold text-gray-900 dark:text-white">
                    ${thisMonthsInvoice.total.toLocaleString()}
                  </span>
                </div>
                
                {thisMonthsInvoice.pdfUrl && (
                  <Button className="w-full" size="sm" data-testid="button-download-invoice">
                    <i className="fas fa-download mr-2"></i>
                    Download PDF
                  </Button>
                )}
              </div>
            ) : (
              <div className="text-center py-4">
                <p className="text-gray-500 dark:text-gray-400">
                  No invoice generated for this month yet
                </p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Recent Tasks */}
        <Card className="bg-white dark:bg-dark-card border dark:border-dark-border">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                Recent Tasks
              </h3>
              <Button variant="ghost" className="text-primary hover:text-blue-700 text-sm">
                View All
              </Button>
            </div>
            
            <div className="space-y-3">
              {assignedTasks.slice(0, 3).map((task) => (
                <div
                  key={task.taskId}
                  className="p-3 border border-gray-200 dark:border-dark-border rounded-lg"
                  data-testid={`card-task-${task.taskId}`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <p className="font-medium text-gray-900 dark:text-white text-sm">
                      {task.title}
                    </p>
                    <Badge variant="secondary" size="sm" className={
                      task.status === "completed" ? "bg-green-100 text-green-800" :
                      task.status === "in-progress" ? "bg-blue-100 text-blue-800" :
                      "bg-gray-100 text-gray-800"
                    }>
                      {task.status}
                    </Badge>
                  </div>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    Due: {task.deadline.toLocaleDateString()}
                  </p>
                </div>
              ))}
              
              {assignedTasks.length === 0 && (
                <div className="text-center py-4 text-gray-500 dark:text-gray-400">
                  <p className="text-sm">No tasks assigned</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
