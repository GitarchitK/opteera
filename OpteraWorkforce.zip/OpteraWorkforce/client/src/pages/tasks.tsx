import { Layout } from "@/components/Layout/Layout";
import { TaskManagement } from "@/components/Tasks/TaskManagement";

export default function TasksPage() {
  return (
    <Layout>
      <TaskManagement />
    </Layout>
  );
}
