import { Layout } from "@/components/Layout/Layout";
import { UserManagement } from "@/components/Users/UserManagement";

export default function UsersPage() {
  return (
    <Layout>
      <UserManagement />
    </Layout>
  );
}
