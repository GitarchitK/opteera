import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useAuth } from "@/hooks/useAuth";
import { useFirestoreCollection } from "@/hooks/useFirestore";
import { Invoice, User, Attendance } from "@shared/schema";
import { where } from "firebase/firestore";
import { formatDisplayDate } from "@/utils/dateHelpers";
import { useToast } from "@/hooks/use-toast";
import { InvoiceGenerator } from "./InvoiceGenerator";

export function InvoiceManagement() {
  const { userProfile } = useAuth();
  const { toast } = useToast();
  const [isGenerateOpen, setIsGenerateOpen] = useState(false);
  const [selectedInvoice, setSelectedInvoice] = useState<Invoice | null>(null);

  const { data: allInvoices } = useFirestoreCollection<Invoice>("invoices");
  const { data: users } = useFirestoreCollection<User>("users");
  const { data: attendance } = useFirestoreCollection<Attendance>("attendance");

  // Filter invoices based on user role
  const invoices = userProfile?.role === "admin" 
    ? allInvoices
    : allInvoices.filter(i => i.userId === userProfile?.uid);

  const getStatusColor = (status: string) => {
    switch (status) {
      case "paid": return "bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400";
      case "sent": return "bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-400";
      case "draft": return "bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-400";
      default: return "bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-400";
    }
  };

  const getUserName = (userId: string) => {
    const user = users.find(u => u.uid === userId);
    return user?.name || "Unknown User";
  };

  const handleDownloadInvoice = (invoice: Invoice) => {
    if (invoice.pdfUrl) {
      window.open(invoice.pdfUrl, '_blank');
    } else {
      toast({
        title: "Error",
        description: "PDF not available for this invoice.",
        variant: "destructive",
      });
    }
  };

  const calculateMonthlyStats = () => {
    const currentMonth = new Date().getMonth();
    const currentYear = new Date().getFullYear();
    
    const monthlyInvoices = invoices.filter(i => i.year === currentYear);
    const totalAmount = monthlyInvoices.reduce((sum, i) => sum + i.total, 0);
    const paidAmount = monthlyInvoices.filter(i => i.status === "paid").reduce((sum, i) => sum + i.total, 0);
    const pendingAmount = monthlyInvoices.filter(i => i.status !== "paid").reduce((sum, i) => sum + i.total, 0);

    return { totalAmount, paidAmount, pendingAmount, totalInvoices: monthlyInvoices.length };
  };

  const stats = calculateMonthlyStats();

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
          {userProfile?.role === "admin" ? "Invoice Management" : 
           userProfile?.role === "contractor" ? "My Invoices" : "My Salary Slips"}
        </h1>
        
        {userProfile?.role === "admin" && (
          <Dialog open={isGenerateOpen} onOpenChange={setIsGenerateOpen}>
            <DialogTrigger asChild>
              <Button className="bg-primary hover:bg-blue-700" data-testid="button-generate-invoices">
                <i className="fas fa-plus mr-2"></i>
                Generate Invoices
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Generate Monthly Invoices</DialogTitle>
              </DialogHeader>
              <InvoiceGenerator onClose={() => setIsGenerateOpen(false)} />
            </DialogContent>
          </Dialog>
        )}
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="bg-white dark:bg-dark-card border dark:border-dark-border">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Total Invoices</p>
                <p className="text-3xl font-bold text-gray-900 dark:text-white">{stats.totalInvoices}</p>
              </div>
              <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900/30 rounded-lg flex items-center justify-center">
                <i className="fas fa-file-invoice text-blue-600 dark:text-blue-400 text-xl"></i>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white dark:bg-dark-card border dark:border-dark-border">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Total Amount</p>
                <p className="text-3xl font-bold text-gray-900 dark:text-white">
                  ${stats.totalAmount.toLocaleString()}
                </p>
              </div>
              <div className="w-12 h-12 bg-green-100 dark:bg-green-900/30 rounded-lg flex items-center justify-center">
                <i className="fas fa-dollar-sign text-green-600 dark:text-green-400 text-xl"></i>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white dark:bg-dark-card border dark:border-dark-border">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Paid Amount</p>
                <p className="text-3xl font-bold text-green-600 dark:text-green-400">
                  ${stats.paidAmount.toLocaleString()}
                </p>
              </div>
              <div className="w-12 h-12 bg-green-100 dark:bg-green-900/30 rounded-lg flex items-center justify-center">
                <i className="fas fa-check-circle text-green-600 dark:text-green-400 text-xl"></i>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white dark:bg-dark-card border dark:border-dark-border">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Pending Amount</p>
                <p className="text-3xl font-bold text-orange-600 dark:text-orange-400">
                  ${stats.pendingAmount.toLocaleString()}
                </p>
              </div>
              <div className="w-12 h-12 bg-orange-100 dark:bg-orange-900/30 rounded-lg flex items-center justify-center">
                <i className="fas fa-clock text-orange-600 dark:text-orange-400 text-xl"></i>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Invoices Table */}
      <Card className="bg-white dark:bg-dark-card border dark:border-dark-border">
        <CardHeader>
          <CardTitle>
            {userProfile?.role === "admin" ? "All Invoices" : "My Invoices"}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Invoice ID</TableHead>
                {userProfile?.role === "admin" && <TableHead>Employee/Contractor</TableHead>}
                <TableHead>Role</TableHead>
                <TableHead>Month/Year</TableHead>
                <TableHead>Amount</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Generated Date</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {invoices.map((invoice) => (
                <TableRow key={invoice.invoiceId} data-testid={`row-invoice-${invoice.invoiceId}`}>
                  <TableCell className="font-mono text-sm">
                    {invoice.invoiceId?.slice(-8)}
                  </TableCell>
                  {userProfile?.role === "admin" && (
                    <TableCell className="font-medium">
                      {getUserName(invoice.userId)}
                    </TableCell>
                  )}
                  <TableCell>
                    <Badge variant="outline" className="capitalize">
                      {invoice.role}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    {invoice.month} {invoice.year}
                  </TableCell>
                  <TableCell className="font-bold">
                    ${invoice.total.toLocaleString()}
                  </TableCell>
                  <TableCell>
                    <Badge className={getStatusColor(invoice.status)}>
                      {invoice.status}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    {formatDisplayDate(invoice.createdAt)}
                  </TableCell>
                  <TableCell>
                    <div className="flex space-x-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => setSelectedInvoice(invoice)}
                        data-testid={`button-view-invoice-${invoice.invoiceId}`}
                      >
                        <i className="fas fa-eye"></i>
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleDownloadInvoice(invoice)}
                        data-testid={`button-download-invoice-${invoice.invoiceId}`}
                      >
                        <i className="fas fa-download"></i>
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          
          {invoices.length === 0 && (
            <div className="text-center py-8">
              <i className="fas fa-file-invoice text-4xl text-gray-400 mb-4"></i>
              <p className="text-gray-500 dark:text-gray-400">
                {userProfile?.role === "admin" 
                  ? "No invoices generated yet. Generate your first invoices to get started."
                  : "No invoices available yet."
                }
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Invoice Detail Modal */}
      {selectedInvoice && (
        <Dialog open={!!selectedInvoice} onOpenChange={() => setSelectedInvoice(null)}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Invoice Details</DialogTitle>
            </DialogHeader>
            <div className="space-y-6">
              {/* Invoice Header */}
              <div className="flex items-center justify-between border-b pb-4">
                <div>
                  <h3 className="text-lg font-bold text-gray-900 dark:text-white">
                    Invoice #{selectedInvoice.invoiceId?.slice(-8)}
                  </h3>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    {selectedInvoice.month} {selectedInvoice.year}
                  </p>
                </div>
                <Badge className={getStatusColor(selectedInvoice.status)}>
                  {selectedInvoice.status}
                </Badge>
              </div>

              {/* Invoice Details */}
              <div className="grid grid-cols-2 gap-6">
                <div>
                  <h4 className="font-medium text-gray-900 dark:text-white mb-2">Bill To:</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    {getUserName(selectedInvoice.userId)}
                  </p>
                  <p className="text-sm text-gray-600 dark:text-gray-400 capitalize">
                    {selectedInvoice.role}
                  </p>
                </div>
                <div>
                  <h4 className="font-medium text-gray-900 dark:text-white mb-2">Invoice Date:</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    {formatDisplayDate(selectedInvoice.createdAt)}
                  </p>
                </div>
              </div>

              {/* Breakdown */}
              <div>
                <h4 className="font-medium text-gray-900 dark:text-white mb-4">Breakdown:</h4>
                <div className="space-y-2">
                  {selectedInvoice.breakdown.baseSalary && (
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-600 dark:text-gray-400">Base Salary:</span>
                      <span className="font-medium">${selectedInvoice.breakdown.baseSalary.toLocaleString()}</span>
                    </div>
                  )}
                  
                  {selectedInvoice.breakdown.contractRate && (
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-600 dark:text-gray-400">Contract Payment:</span>
                      <span className="font-medium">${selectedInvoice.breakdown.contractRate.toLocaleString()}</span>
                    </div>
                  )}
                  
                  {selectedInvoice.breakdown.overtimeAmount > 0 && (
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-600 dark:text-gray-400">
                        Overtime ({selectedInvoice.breakdown.overtimeHours} hrs):
                      </span>
                      <span className="font-medium">${selectedInvoice.breakdown.overtimeAmount.toLocaleString()}</span>
                    </div>
                  )}
                  
                  {selectedInvoice.breakdown.bonuses > 0 && (
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-600 dark:text-gray-400">Bonuses:</span>
                      <span className="font-medium text-green-600">+${selectedInvoice.breakdown.bonuses.toLocaleString()}</span>
                    </div>
                  )}
                  
                  {selectedInvoice.breakdown.deductions > 0 && (
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-600 dark:text-gray-400">Deductions:</span>
                      <span className="font-medium text-red-600">-${selectedInvoice.breakdown.deductions.toLocaleString()}</span>
                    </div>
                  )}
                </div>
                
                <div className="border-t pt-2 mt-4">
                  <div className="flex justify-between text-lg font-bold">
                    <span>Total:</span>
                    <span>${selectedInvoice.total.toLocaleString()}</span>
                  </div>
                </div>
              </div>

              {/* Actions */}
              <div className="flex space-x-2">
                <Button
                  onClick={() => handleDownloadInvoice(selectedInvoice)}
                  className="flex-1"
                  data-testid="button-download-selected-invoice"
                >
                  <i className="fas fa-download mr-2"></i>
                  Download PDF
                </Button>
                <Button
                  variant="outline"
                  onClick={() => setSelectedInvoice(null)}
                  data-testid="button-close-invoice-detail"
                >
                  Close
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
