import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";
import { useFirestoreCollection, addFirestoreDocument, updateFirestoreDocument } from "@/hooks/useFirestore";
import { Attendance } from "@shared/schema";
import { where } from "firebase/firestore";
import { formatDateString } from "@/utils/dateHelpers";
import { formatTime } from "@/utils/timezone";
import { useToast } from "@/hooks/use-toast";

export function ClockInOut() {
  const { userProfile } = useAuth();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  
  const today = formatDateString(new Date());
  
  const { data: todayAttendance } = useFirestoreCollection<Attendance>(
    "attendance",
    [
      where("userId", "==", userProfile?.uid || ""),
      where("date", "==", today)
    ]
  );

  const currentAttendance = todayAttendance[0];

  const handleClockIn = async () => {
    if (!userProfile) return;
    
    setLoading(true);
    try {
      const now = new Date();
      await addFirestoreDocument("attendance", {
        userId: userProfile.uid,
        date: today,
        checkInTime: now,
        status: "present",
        totalHours: 0,
        overtimeHours: 0,
      });
      
      toast({
        title: "Clocked In",
        description: `Successfully clocked in at ${formatTime(now)}`,
      });
    } catch (error) {
      console.error("Clock in error:", error);
      toast({
        title: "Error",
        description: "Failed to clock in. Please try again.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleClockOut = async () => {
    if (!userProfile || !currentAttendance?.attendanceId) return;
    
    setLoading(true);
    try {
      const now = new Date();
      const checkInTime = currentAttendance.checkInTime;
      
      if (!checkInTime) {
        toast({
          title: "Error",
          description: "No check-in time found.",
          variant: "destructive",
        });
        return;
      }

      // Calculate total hours
      const totalHours = (now.getTime() - checkInTime.getTime()) / (1000 * 60 * 60);
      const standardHours = 8; // Standard work day
      const overtimeHours = Math.max(0, totalHours - standardHours);
      
      await updateFirestoreDocument("attendance", currentAttendance.attendanceId, {
        checkOutTime: now,
        totalHours: totalHours,
        overtimeHours: overtimeHours,
      });
      
      toast({
        title: "Clocked Out",
        description: `Successfully clocked out at ${formatTime(now)}. Total: ${totalHours.toFixed(2)} hours`,
      });
    } catch (error) {
      console.error("Clock out error:", error);
      toast({
        title: "Error",
        description: "Failed to clock out. Please try again.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const isWorking = currentAttendance?.checkInTime && !currentAttendance?.checkOutTime;

  return (
    <Card className="bg-white dark:bg-dark-card border dark:border-dark-border">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <i className="fas fa-clock text-primary"></i>
          <span>Time Tracking</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="text-center">
          <p className="text-2xl font-bold text-gray-900 dark:text-white">
            {formatTime(new Date())}
          </p>
          <p className="text-sm text-gray-500 dark:text-gray-400">
            {new Date().toLocaleDateString('en-US', { 
              weekday: 'long', 
              year: 'numeric', 
              month: 'long', 
              day: 'numeric' 
            })}
          </p>
        </div>

        {currentAttendance && (
          <div className="space-y-3 p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
            <h4 className="font-medium text-gray-900 dark:text-white">Today's Summary</h4>
            
            {currentAttendance.checkInTime && (
              <div className="flex justify-between">
                <span className="text-sm text-gray-600 dark:text-gray-400">Check In:</span>
                <span className="text-sm font-medium">
                  {formatTime(currentAttendance.checkInTime)}
                </span>
              </div>
            )}
            
            {currentAttendance.checkOutTime && (
              <div className="flex justify-between">
                <span className="text-sm text-gray-600 dark:text-gray-400">Check Out:</span>
                <span className="text-sm font-medium">
                  {formatTime(currentAttendance.checkOutTime)}
                </span>
              </div>
            )}
            
            <div className="flex justify-between">
              <span className="text-sm text-gray-600 dark:text-gray-400">Total Hours:</span>
              <span className="text-sm font-medium">
                {currentAttendance.totalHours.toFixed(2)}
              </span>
            </div>
            
            {currentAttendance.overtimeHours > 0 && (
              <div className="flex justify-between">
                <span className="text-sm text-gray-600 dark:text-gray-400">Overtime:</span>
                <span className="text-sm font-medium text-orange-600">
                  {currentAttendance.overtimeHours.toFixed(2)} hrs
                </span>
              </div>
            )}
          </div>
        )}

        <div className="flex space-x-3">
          {!isWorking ? (
            <Button
              onClick={handleClockIn}
              disabled={loading}
              className="flex-1 bg-green-600 hover:bg-green-700 text-white"
              data-testid="button-clock-in"
            >
              {loading ? (
                <i className="fas fa-spinner fa-spin mr-2"></i>
              ) : (
                <i className="fas fa-play mr-2"></i>
              )}
              Clock In
            </Button>
          ) : (
            <Button
              onClick={handleClockOut}
              disabled={loading}
              className="flex-1 bg-red-600 hover:bg-red-700 text-white"
              data-testid="button-clock-out"
            >
              {loading ? (
                <i className="fas fa-spinner fa-spin mr-2"></i>
              ) : (
                <i className="fas fa-stop mr-2"></i>
              )}
              Clock Out
            </Button>
          )}
        </div>
        
        {isWorking && (
          <div className="text-center p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
            <p className="text-sm text-green-700 dark:text-green-300">
              <i className="fas fa-clock mr-1"></i>
              You are currently clocked in
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
