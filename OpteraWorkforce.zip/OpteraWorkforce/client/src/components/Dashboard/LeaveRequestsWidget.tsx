import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useFirestoreCollection, updateFirestoreDocument } from "@/hooks/useFirestore";
import { Leave, User } from "@shared/schema";
import { where } from "firebase/firestore";
import { formatDisplayDate } from "@/utils/dateHelpers";
import { useToast } from "@/hooks/use-toast";

export function LeaveRequestsWidget() {
  const { toast } = useToast();
  const { data: pendingLeaves } = useFirestoreCollection<Leave>(
    "leaves",
    [where("status", "==", "pending")]
  );

  const { data: users } = useFirestoreCollection<User>("users");

  const handleLeaveAction = async (leaveId: string, action: "approved" | "rejected") => {
    try {
      await updateFirestoreDocument("leaves", leaveId, {
        status: action,
        approvedBy: "current-admin-id", // This should be the current admin's ID
      });
      
      toast({
        title: `Leave ${action}`,
        description: `Leave request has been ${action} successfully.`,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: `Failed to ${action.slice(0, -1)} leave request.`,
        variant: "destructive",
      });
    }
  };

  const getLeaveTypeColor = (type: string) => {
    switch (type) {
      case "sick": return "border-red-400";
      case "vacation": return "border-blue-400";
      case "personal": return "border-purple-400";
      case "emergency": return "border-orange-400";
      default: return "border-gray-400";
    }
  };

  return (
    <Card className="bg-white dark:bg-dark-card border dark:border-dark-border">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
            Leave Requests
          </h3>
          <Badge 
            variant="secondary" 
            className="bg-yellow-100 dark:bg-yellow-900/30 text-yellow-800 dark:text-yellow-200"
            data-testid="badge-pending-count"
          >
            {pendingLeaves.length} Pending
          </Badge>
        </div>
        
        <div className="space-y-4">
          {pendingLeaves.length > 0 ? (
            pendingLeaves.slice(0, 3).map((leave) => {
              const user = users.find(u => u.uid === leave.userId);
              if (!user) return null;

              return (
                <div
                  key={leave.leaveId}
                  className={`border-l-4 pl-4 py-2 ${getLeaveTypeColor(leave.type)}`}
                  data-testid={`card-leave-request-${leave.leaveId}`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <p className="font-medium text-gray-900 dark:text-white">
                      {user.name}
                    </p>
                    <span className="text-xs text-gray-500 dark:text-gray-400">
                      {formatDisplayDate(leave.createdAt)}
                    </span>
                  </div>
                  <p className="text-sm text-gray-600 dark:text-gray-400 mb-1 capitalize">
                    {leave.type} Leave
                  </p>
                  <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">
                    {leave.reason}
                  </p>
                  <p className="text-xs text-gray-500 dark:text-gray-400 mb-3">
                    {formatDisplayDate(leave.fromDate)} - {formatDisplayDate(leave.toDate)}
                  </p>
                  <div className="flex space-x-2">
                    <Button
                      size="sm"
                      variant="ghost"
                      className="px-3 py-1 bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-300 text-xs hover:bg-green-200 dark:hover:bg-green-900/50"
                      onClick={() => handleLeaveAction(leave.leaveId!, "approved")}
                      data-testid={`button-approve-leave-${leave.leaveId}`}
                    >
                      Approve
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      className="px-3 py-1 bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-300 text-xs hover:bg-red-200 dark:hover:bg-red-900/50"
                      onClick={() => handleLeaveAction(leave.leaveId!, "rejected")}
                      data-testid={`button-reject-leave-${leave.leaveId}`}
                    >
                      Reject
                    </Button>
                  </div>
                </div>
              );
            })
          ) : (
            <div className="text-center py-8 text-gray-500 dark:text-gray-400">
              <p>No pending leave requests</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
