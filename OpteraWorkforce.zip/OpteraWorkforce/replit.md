# Optera Employee Management System

## Overview

Optera is a modern React-based employee and contractor management system built with Firebase as the backend. The application provides comprehensive workforce management capabilities including user management, project tracking, task assignment, attendance monitoring, leave management, and invoice generation. The system supports role-based access control with three distinct user types: Admin, Employee, and Contractor.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript for type safety
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: React Context API for authentication and theme management, TanStack Query for server state
- **UI Components**: shadcn/ui component library built on Radix UI primitives
- **Styling**: Tailwind CSS with custom design tokens and dark mode support
- **Build Tool**: Vite for fast development and optimized production builds

### Backend Architecture
- **Express Server**: Minimal Express.js setup for serving the React application
- **API Structure**: RESTful API endpoints with `/api` prefix
- **Database Abstraction**: Storage interface pattern with in-memory implementation as fallback
- **Session Management**: Express sessions with PostgreSQL session store support

### Authentication & Authorization
- **Firebase Authentication**: Email/password authentication with Firebase Auth
- **Role-based Access Control**: Three user roles (admin, employee, contractor) with different permissions
- **Admin-controlled Registration**: Only admins can create new user accounts, preventing self-registration

### Data Storage Solutions
- **Primary Database**: Firebase Firestore for real-time data synchronization
- **Backup Database**: Drizzle ORM with PostgreSQL support via Neon Database
- **File Storage**: Firebase Storage for document and invoice PDFs
- **Session Storage**: PostgreSQL-backed session store for Express sessions

### Database Schema Design
The system uses a comprehensive schema with the following core entities:
- **Users**: Role-based user profiles with salary/contract rate information
- **Projects**: Project management with employee/contractor assignments
- **Tasks**: Task tracking with priority levels and deadline management
- **Attendance**: Time tracking with check-in/out and overtime calculations
- **Leaves**: Leave request management with approval workflow
- **Invoices**: Automated invoice generation with PDF storage
- **Notifications**: System-wide notification management

### Real-time Features
- **Live Data Updates**: Firestore real-time listeners for instant UI updates
- **Custom Hooks**: useFirestoreCollection hook for reactive data fetching
- **Optimistic Updates**: Client-side state updates with server synchronization

### UI/UX Design Patterns
- **Responsive Design**: Mobile-first approach with adaptive layouts
- **Dark Mode**: System-wide theme switching with user preference persistence
- **Component Architecture**: Modular component structure with shared UI components
- **Accessibility**: ARIA-compliant components with keyboard navigation support

## External Dependencies

### Firebase Services
- **Firebase Authentication**: User authentication and session management
- **Firestore Database**: Primary NoSQL database for real-time data storage
- **Firebase Storage**: File storage for invoices and document attachments
- **Configuration**: Environment-based Firebase project configuration

### Database & ORM
- **Drizzle ORM**: TypeScript-first ORM for PostgreSQL interactions
- **Neon Database**: Serverless PostgreSQL for backup data storage
- **PostgreSQL Session Store**: connect-pg-simple for Express session persistence

### UI & Styling
- **Radix UI**: Headless UI components for accessibility and customization
- **Tailwind CSS**: Utility-first CSS framework with custom design system
- **Lucide Icons**: Modern icon library for consistent iconography
- **Font Awesome**: Additional icon support for legacy components

### Development & Build Tools
- **TypeScript**: Static type checking across the entire codebase
- **Vite**: Build tool with HMR and optimized production builds
- **ESBuild**: Fast JavaScript bundler for server-side code
- **PostCSS**: CSS processing with Tailwind CSS integration

### Form & Validation
- **React Hook Form**: Performant form handling with minimal re-renders
- **Zod**: Schema validation for type-safe data handling
- **Hookform Resolvers**: Integration between React Hook Form and Zod

### Date & Time Management
- **date-fns**: Lightweight date manipulation and formatting library
- **Timezone Handling**: Browser-based timezone detection and formatting utilities

### Development Environment
- **Replit Integration**: Cartographer plugin for Replit-specific development features
- **Runtime Error Overlay**: Development error handling and debugging tools
- **Hot Module Replacement**: Fast development iteration with Vite HMR