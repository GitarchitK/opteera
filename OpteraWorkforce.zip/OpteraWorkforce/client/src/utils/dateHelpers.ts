import { format, parseISO, startOfDay, endOfDay, isAfter, isBefore } from 'date-fns';

export function formatDateString(date: Date | string): string {
  const dateObj = typeof date === 'string' ? parseISO(date) : date;
  return format(dateObj, 'yyyy-MM-dd');
}

export function formatDisplayDate(date: Date | string): string {
  const dateObj = typeof date === 'string' ? parseISO(date) : date;
  return format(dateObj, 'MMM dd, yyyy');
}

export function isDateInRange(date: Date, startDate: Date, endDate: Date): boolean {
  const checkDate = startOfDay(date);
  const start = startOfDay(startDate);
  const end = endOfDay(endDate);
  
  return !isBefore(checkDate, start) && !isAfter(checkDate, end);
}

export function calculateWorkingDays(startDate: Date, endDate: Date): number {
  let count = 0;
  const current = new Date(startDate);
  
  while (current <= endDate) {
    const dayOfWeek = current.getDay();
    if (dayOfWeek !== 0 && dayOfWeek !== 6) { // Not Sunday (0) or Saturday (6)
      count++;
    }
    current.setDate(current.getDate() + 1);
  }
  
  return count;
}

export function calculateHoursDifference(startTime: Date, endTime: Date): number {
  const diffMs = endTime.getTime() - startTime.getTime();
  return Math.max(0, diffMs / (1000 * 60 * 60)); // Convert to hours
}
