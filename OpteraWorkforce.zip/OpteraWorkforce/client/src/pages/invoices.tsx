import { Layout } from "@/components/Layout/Layout";
import { InvoiceManagement } from "@/components/Invoices/InvoiceManagement";

export default function InvoicesPage() {
  return (
    <Layout>
      <InvoiceManagement />
    </Layout>
  );
}
