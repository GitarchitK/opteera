import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { useFirestoreCollection } from "@/hooks/useFirestore";
import { Project, Task } from "@shared/schema";
import { where } from "firebase/firestore";
import { formatDisplayDate } from "@/utils/dateHelpers";

export function ProjectsWidget() {
  const { data: activeProjects } = useFirestoreCollection<Project>(
    "projects",
    [where("status", "==", "active")]
  );

  const { data: allTasks } = useFirestoreCollection<Task>("tasks");

  const getProjectProgress = (projectId: string) => {
    const projectTasks = allTasks.filter(task => task.projectId === projectId);
    if (projectTasks.length === 0) return 0;
    
    const completedTasks = projectTasks.filter(task => task.status === "completed");
    return Math.round((completedTasks.length / projectTasks.length) * 100);
  };

  const getProjectStatus = (project: Project) => {
    const progress = getProjectProgress(project.projectId);
    const isOverdue = project.endDate && new Date() > project.endDate;
    
    if (isOverdue) return { status: "overdue", color: "bg-red-500" };
    if (progress >= 85) return { status: "near-complete", color: "bg-green-500" };
    if (progress >= 50) return { status: "in-progress", color: "bg-yellow-500" };
    return { status: "started", color: "bg-blue-500" };
  };

  return (
    <Card className="bg-white dark:bg-dark-card border dark:border-dark-border">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
            Recent Projects
          </h3>
          <Button variant="ghost" className="text-primary hover:text-blue-700 text-sm font-medium" data-testid="button-view-all-projects">
            View All
          </Button>
        </div>
        
        <div className="space-y-4">
          {activeProjects.length > 0 ? (
            activeProjects.slice(0, 3).map((project) => {
              const progress = getProjectProgress(project.projectId);
              const statusInfo = getProjectStatus(project);
              const totalMembers = project.assignedEmployees.length + project.assignedContractors.length;

              return (
                <div
                  key={project.projectId}
                  className="flex items-center justify-between p-4 border border-gray-200 dark:border-dark-border rounded-lg"
                  data-testid={`card-project-${project.projectId}`}
                >
                  <div className="flex items-center space-x-4">
                    <div className={`w-3 h-3 ${statusInfo.color} rounded-full`}></div>
                    <div>
                      <p className="font-medium text-gray-900 dark:text-white">
                        {project.name}
                      </p>
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        {totalMembers} members • Due {project.endDate ? formatDisplayDate(project.endDate) : "No deadline"}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className={`text-sm font-medium ${
                      statusInfo.status === "overdue" 
                        ? "text-red-600 dark:text-red-400"
                        : statusInfo.status === "near-complete"
                        ? "text-green-600 dark:text-green-400"
                        : "text-yellow-600 dark:text-yellow-400"
                    }`}>
                      {progress}%
                    </p>
                    <div className="w-20 mt-1">
                      <Progress 
                        value={progress} 
                        className="h-2"
                      />
                    </div>
                  </div>
                </div>
              );
            })
          ) : (
            <div className="text-center py-8 text-gray-500 dark:text-gray-400">
              <p>No active projects</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
