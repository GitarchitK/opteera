import { z } from "zod";

// User schema
export const userSchema = z.object({
  uid: z.string(),
  role: z.enum(['admin', 'employee', 'contractor']),
  name: z.string(),
  email: z.string().email(),
  position: z.string().optional(),
  salary: z.number().optional(),
  contractRate: z.number().optional(),
  overtimeRate: z.number().optional(),
  isActive: z.boolean().default(true),
  createdAt: z.date(),
  updatedAt: z.date().optional(),
});

// Project schema
export const projectSchema = z.object({
  projectId: z.string(),
  name: z.string(),
  description: z.string(),
  assignedEmployees: z.array(z.string()),
  assignedContractors: z.array(z.string()),
  status: z.enum(['active', 'completed', 'on-hold', 'cancelled']),
  startDate: z.date(),
  endDate: z.date().optional(),
  createdAt: z.date(),
  updatedAt: z.date().optional(),
});

// Task schema
export const taskSchema = z.object({
  taskId: z.string(),
  title: z.string(),
  description: z.string(),
  assignedTo: z.string(),
  projectId: z.string(),
  deadline: z.date(),
  status: z.enum(['pending', 'in-progress', 'completed']),
  priority: z.enum(['low', 'medium', 'high']).default('medium'),
  createdAt: z.date(),
  updatedAt: z.date().optional(),
});

// Invoice schema
export const invoiceSchema = z.object({
  invoiceId: z.string(),
  userId: z.string(),
  role: z.enum(['employee', 'contractor']),
  month: z.string(),
  year: z.number(),
  breakdown: z.object({
    baseSalary: z.number().optional(),
    contractRate: z.number().optional(),
    overtimeHours: z.number().default(0),
    overtimeAmount: z.number().default(0),
    bonuses: z.number().default(0),
    deductions: z.number().default(0),
  }),
  total: z.number(),
  pdfUrl: z.string().optional(),
  status: z.enum(['draft', 'sent', 'paid']).default('draft'),
  createdAt: z.date(),
  updatedAt: z.date().optional(),
});

// Attendance schema
export const attendanceSchema = z.object({
  attendanceId: z.string(),
  userId: z.string(),
  date: z.string(), // YYYY-MM-DD format
  checkInTime: z.date().optional(),
  checkOutTime: z.date().optional(),
  totalHours: z.number().default(0),
  overtimeHours: z.number().default(0),
  status: z.enum(['present', 'absent', 'late', 'on-leave']),
  notes: z.string().optional(),
  createdAt: z.date(),
  updatedAt: z.date().optional(),
});

// Leave schema
export const leaveSchema = z.object({
  leaveId: z.string(),
  userId: z.string(),
  fromDate: z.date(),
  toDate: z.date(),
  reason: z.string(),
  type: z.enum(['sick', 'vacation', 'personal', 'emergency']),
  status: z.enum(['pending', 'approved', 'rejected']),
  approvedBy: z.string().optional(),
  notes: z.string().optional(),
  createdAt: z.date(),
  updatedAt: z.date().optional(),
});

// Notification schema
export const notificationSchema = z.object({
  notificationId: z.string(),
  title: z.string(),
  message: z.string(),
  targetUsers: z.array(z.string()), // array of user IDs, or ['all'] for all users
  targetRoles: z.array(z.enum(['admin', 'employee', 'contractor'])).optional(),
  type: z.enum(['announcement', 'system', 'reminder']).default('announcement'),
  priority: z.enum(['low', 'medium', 'high']).default('medium'),
  isRead: z.record(z.boolean()).default({}), // userId -> isRead mapping
  createdAt: z.date(),
  expiresAt: z.date().optional(),
});

// Insert schemas
export const insertUserSchema = userSchema.omit({ uid: true, createdAt: true, updatedAt: true });
export const insertProjectSchema = projectSchema.omit({ projectId: true, createdAt: true, updatedAt: true });
export const insertTaskSchema = taskSchema.omit({ taskId: true, createdAt: true, updatedAt: true });
export const insertInvoiceSchema = invoiceSchema.omit({ invoiceId: true, createdAt: true, updatedAt: true });
export const insertAttendanceSchema = attendanceSchema.omit({ attendanceId: true, createdAt: true, updatedAt: true });
export const insertLeaveSchema = leaveSchema.omit({ leaveId: true, createdAt: true, updatedAt: true });
export const insertNotificationSchema = notificationSchema.omit({ notificationId: true, createdAt: true });

// Types
export type User = z.infer<typeof userSchema>;
export type Project = z.infer<typeof projectSchema>;
export type Task = z.infer<typeof taskSchema>;
export type Invoice = z.infer<typeof invoiceSchema>;
export type Attendance = z.infer<typeof attendanceSchema>;
export type Leave = z.infer<typeof leaveSchema>;
export type Notification = z.infer<typeof notificationSchema>;

export type InsertUser = z.infer<typeof insertUserSchema>;
export type InsertProject = z.infer<typeof insertProjectSchema>;
export type InsertTask = z.infer<typeof insertTaskSchema>;
export type InsertInvoice = z.infer<typeof insertInvoiceSchema>;
export type InsertAttendance = z.infer<typeof insertAttendanceSchema>;
export type InsertLeave = z.infer<typeof insertLeaveSchema>;
export type InsertNotification = z.infer<typeof insertNotificationSchema>;

export type UserRole = 'admin' | 'employee' | 'contractor';
export type ProjectStatus = 'active' | 'completed' | 'on-hold' | 'cancelled';
export type TaskStatus = 'pending' | 'in-progress' | 'completed';
export type LeaveStatus = 'pending' | 'approved' | 'rejected';
export type AttendanceStatus = 'present' | 'absent' | 'late' | 'on-leave';
