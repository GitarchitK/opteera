import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useAuth } from "@/hooks/useAuth";
import { useFirestoreCollection, addFirestoreDocument, updateFirestoreDocument } from "@/hooks/useFirestore";
import { Leave, User, InsertLeave } from "@shared/schema";
import { where } from "firebase/firestore";
import { formatDisplayDate, calculateWorkingDays } from "@/utils/dateHelpers";
import { useToast } from "@/hooks/use-toast";

export function LeaveManagement() {
  const { userProfile } = useAuth();
  const { toast } = useToast();
  const [isApplyOpen, setIsApplyOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState("all");

  const { data: allLeaves } = useFirestoreCollection<Leave>("leaves");
  const { data: users } = useFirestoreCollection<User>("users");

  // Filter leaves based on user role
  const leaves = userProfile?.role === "admin" 
    ? allLeaves
    : allLeaves.filter(l => l.userId === userProfile?.uid);

  const [newLeave, setNewLeave] = useState<InsertLeave>({
    userId: userProfile?.uid || "",
    fromDate: new Date(),
    toDate: new Date(),
    reason: "",
    type: "vacation",
    status: "pending",
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case "approved": return "bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400";
      case "rejected": return "bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-400";
      case "pending": return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-400";
      default: return "bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-400";
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case "sick": return "bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-400";
      case "vacation": return "bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-400";
      case "personal": return "bg-purple-100 text-purple-800 dark:bg-purple-900/20 dark:text-purple-400";
      case "emergency": return "bg-orange-100 text-orange-800 dark:bg-orange-900/20 dark:text-orange-400";
      default: return "bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-400";
    }
  };

  const filteredLeaves = leaves.filter(leave => {
    switch (activeTab) {
      case "pending": return leave.status === "pending";
      case "approved": return leave.status === "approved";
      case "rejected": return leave.status === "rejected";
      default: return true;
    }
  });

  const handleApplyLeave = async () => {
    if (!newLeave.reason || !newLeave.fromDate || !newLeave.toDate) {
      toast({
        title: "Error",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }

    if (newLeave.fromDate > newLeave.toDate) {
      toast({
        title: "Error",
        description: "From date cannot be after to date.",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    try {
      await addFirestoreDocument("leaves", {
        ...newLeave,
        leaveId: `leave_${Date.now()}`,
      });

      toast({
        title: "Success",
        description: "Leave request submitted successfully!",
      });

      setIsApplyOpen(false);
      setNewLeave({
        userId: userProfile?.uid || "",
        fromDate: new Date(),
        toDate: new Date(),
        reason: "",
        type: "vacation",
        status: "pending",
      });
    } catch (error) {
      console.error("Apply leave error:", error);
      toast({
        title: "Error",
        description: "Failed to submit leave request.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleLeaveAction = async (leaveId: string, action: "approved" | "rejected") => {
    try {
      await updateFirestoreDocument("leaves", leaveId, {
        status: action,
        approvedBy: userProfile?.uid,
      });

      toast({
        title: "Success",
        description: `Leave request ${action} successfully.`,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: `Failed to ${action.slice(0, -1)} leave request.`,
        variant: "destructive",
      });
    }
  };

  const getUserName = (userId: string) => {
    const user = users.find(u => u.uid === userId);
    return user?.name || "Unknown User";
  };

  const calculateLeaveDays = (leave: Leave) => {
    return calculateWorkingDays(leave.fromDate, leave.toDate);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
          {userProfile?.role === "admin" ? "Leave Management" : "My Leave Requests"}
        </h1>
        
        {userProfile?.role !== "admin" && (
          <Dialog open={isApplyOpen} onOpenChange={setIsApplyOpen}>
            <DialogTrigger asChild>
              <Button className="bg-primary hover:bg-blue-700" data-testid="button-apply-leave">
                <i className="fas fa-plus mr-2"></i>
                Apply for Leave
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>Apply for Leave</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="type">Leave Type *</Label>
                  <Select
                    value={newLeave.type}
                    onValueChange={(value) => setNewLeave(prev => ({ ...prev, type: value as Leave["type"] }))}
                  >
                    <SelectTrigger data-testid="select-leave-type">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="vacation">Vacation</SelectItem>
                      <SelectItem value="sick">Sick Leave</SelectItem>
                      <SelectItem value="personal">Personal Leave</SelectItem>
                      <SelectItem value="emergency">Emergency Leave</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label htmlFor="fromDate">From Date *</Label>
                  <Input
                    id="fromDate"
                    type="date"
                    value={newLeave.fromDate.toISOString().split('T')[0]}
                    onChange={(e) => setNewLeave(prev => ({ ...prev, fromDate: new Date(e.target.value) }))}
                    data-testid="input-leave-from-date"
                  />
                </div>
                
                <div>
                  <Label htmlFor="toDate">To Date *</Label>
                  <Input
                    id="toDate"
                    type="date"
                    value={newLeave.toDate.toISOString().split('T')[0]}
                    onChange={(e) => setNewLeave(prev => ({ ...prev, toDate: new Date(e.target.value) }))}
                    data-testid="input-leave-to-date"
                  />
                </div>
                
                <div>
                  <Label htmlFor="reason">Reason *</Label>
                  <Textarea
                    id="reason"
                    value={newLeave.reason}
                    onChange={(e) => setNewLeave(prev => ({ ...prev, reason: e.target.value }))}
                    placeholder="Enter reason for leave"
                    rows={3}
                    data-testid="textarea-leave-reason"
                  />
                </div>
                
                <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                  <p className="text-sm text-blue-700 dark:text-blue-300">
                    <strong>Duration:</strong> {calculateWorkingDays(newLeave.fromDate, newLeave.toDate)} working day(s)
                  </p>
                </div>
                
                <div className="flex space-x-2 pt-4">
                  <Button
                    onClick={handleApplyLeave}
                    disabled={loading}
                    className="flex-1 bg-primary hover:bg-blue-700"
                    data-testid="button-submit-leave"
                  >
                    {loading ? (
                      <>
                        <i className="fas fa-spinner fa-spin mr-2"></i>
                        Submitting...
                      </>
                    ) : (
                      "Submit Request"
                    )}
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => setIsApplyOpen(false)}
                    disabled={loading}
                    data-testid="button-cancel-leave"
                  >
                    Cancel
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        )}
      </div>

      {userProfile?.role === "admin" && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="bg-white dark:bg-dark-card border dark:border-dark-border">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Pending</p>
                  <p className="text-3xl font-bold text-yellow-600 dark:text-yellow-400">
                    {allLeaves.filter(l => l.status === "pending").length}
                  </p>
                </div>
                <div className="w-12 h-12 bg-yellow-100 dark:bg-yellow-900/30 rounded-lg flex items-center justify-center">
                  <i className="fas fa-clock text-yellow-600 dark:text-yellow-400 text-xl"></i>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white dark:bg-dark-card border dark:border-dark-border">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Approved</p>
                  <p className="text-3xl font-bold text-green-600 dark:text-green-400">
                    {allLeaves.filter(l => l.status === "approved").length}
                  </p>
                </div>
                <div className="w-12 h-12 bg-green-100 dark:bg-green-900/30 rounded-lg flex items-center justify-center">
                  <i className="fas fa-check text-green-600 dark:text-green-400 text-xl"></i>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white dark:bg-dark-card border dark:border-dark-border">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Rejected</p>
                  <p className="text-3xl font-bold text-red-600 dark:text-red-400">
                    {allLeaves.filter(l => l.status === "rejected").length}
                  </p>
                </div>
                <div className="w-12 h-12 bg-red-100 dark:bg-red-900/30 rounded-lg flex items-center justify-center">
                  <i className="fas fa-times text-red-600 dark:text-red-400 text-xl"></i>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="all" data-testid="tab-all-leaves">
            All ({leaves.length})
          </TabsTrigger>
          <TabsTrigger value="pending" data-testid="tab-pending-leaves">
            Pending ({leaves.filter(l => l.status === "pending").length})
          </TabsTrigger>
          <TabsTrigger value="approved" data-testid="tab-approved-leaves">
            Approved ({leaves.filter(l => l.status === "approved").length})
          </TabsTrigger>
          <TabsTrigger value="rejected" data-testid="tab-rejected-leaves">
            Rejected ({leaves.filter(l => l.status === "rejected").length})
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value={activeTab}>
          <Card className="bg-white dark:bg-dark-card border dark:border-dark-border">
            <CardContent className="p-6">
              <Table>
                <TableHeader>
                  <TableRow>
                    {userProfile?.role === "admin" && <TableHead>Employee</TableHead>}
                    <TableHead>Type</TableHead>
                    <TableHead>From Date</TableHead>
                    <TableHead>To Date</TableHead>
                    <TableHead>Days</TableHead>
                    <TableHead>Reason</TableHead>
                    <TableHead>Status</TableHead>
                    {userProfile?.role === "admin" && <TableHead>Actions</TableHead>}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredLeaves.map((leave) => (
                    <TableRow key={leave.leaveId} data-testid={`row-leave-${leave.leaveId}`}>
                      {userProfile?.role === "admin" && (
                        <TableCell className="font-medium">
                          {getUserName(leave.userId)}
                        </TableCell>
                      )}
                      <TableCell>
                        <Badge className={getTypeColor(leave.type)}>
                          {leave.type}
                        </Badge>
                      </TableCell>
                      <TableCell>{formatDisplayDate(leave.fromDate)}</TableCell>
                      <TableCell>{formatDisplayDate(leave.toDate)}</TableCell>
                      <TableCell>{calculateLeaveDays(leave)} days</TableCell>
                      <TableCell className="max-w-xs truncate">{leave.reason}</TableCell>
                      <TableCell>
                        <Badge className={getStatusColor(leave.status)}>
                          {leave.status}
                        </Badge>
                      </TableCell>
                      {userProfile?.role === "admin" && leave.status === "pending" && (
                        <TableCell>
                          <div className="flex space-x-2">
                            <Button
                              size="sm"
                              variant="outline"
                              className="bg-green-50 hover:bg-green-100 text-green-700 border-green-200"
                              onClick={() => handleLeaveAction(leave.leaveId!, "approved")}
                              data-testid={`button-approve-leave-${leave.leaveId}`}
                            >
                              <i className="fas fa-check text-xs"></i>
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              className="bg-red-50 hover:bg-red-100 text-red-700 border-red-200"
                              onClick={() => handleLeaveAction(leave.leaveId!, "rejected")}
                              data-testid={`button-reject-leave-${leave.leaveId}`}
                            >
                              <i className="fas fa-times text-xs"></i>
                            </Button>
                          </div>
                        </TableCell>
                      )}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
              
              {filteredLeaves.length === 0 && (
                <div className="text-center py-8">
                  <p className="text-gray-500 dark:text-gray-400">
                    No leave requests found for the selected filter.
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
