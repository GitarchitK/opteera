export interface DashboardStats {
  totalEmployees: number;
  activeContractors: number;
  activeProjects: number;
  pendingTasks: number;
  presentToday: number;
  absentToday: number;
  onLeaveToday: number;
  pendingLeaves: number;
}

export interface AttendanceSummary {
  present: number;
  absent: number;
  onLeave: number;
  late: number;
}

export interface RecentCheckIn {
  userId: string;
  name: string;
  position: string;
  checkInTime: Date;
  status: 'on-time' | 'late';
}

export interface ProjectProgress {
  projectId: string;
  name: string;
  members: number;
  dueDate: Date;
  progress: number;
  status: 'active' | 'completed' | 'overdue';
}

export interface InvoiceData {
  month: string;
  year: number;
  employeesProcessed: number;
  totalAmount: number;
  status: 'draft' | 'sent' | 'paid';
}
