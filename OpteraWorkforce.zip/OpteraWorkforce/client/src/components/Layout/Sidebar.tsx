import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import { useFirestoreCollection } from "@/hooks/useFirestore";
import { User, Task, Leave } from "@shared/schema";
import { where } from "firebase/firestore";
import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";

interface SidebarItemProps {
  href: string;
  icon: string;
  label: string;
  badge?: number;
  badgeColor?: string;
  isActive?: boolean;
}

function SidebarItem({ href, icon, label, badge, badgeColor = "bg-primary", isActive }: SidebarItemProps) {
  return (
    <Link href={href}>
      <a
        className={cn(
          "flex items-center space-x-3 px-4 py-3 rounded-lg font-medium transition-colors",
          isActive
            ? "text-primary bg-blue-50 dark:bg-primary/20"
            : "text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800"
        )}
        data-testid={`link-${label.toLowerCase().replace(/\s+/g, '-')}`}
      >
        <i className={icon}></i>
        <span>{label}</span>
        {badge !== undefined && badge > 0 && (
          <Badge
            variant="secondary"
            className={cn("ml-auto text-white px-2 py-1 text-xs", badgeColor)}
          >
            {badge}
          </Badge>
        )}
      </a>
    </Link>
  );
}

function SidebarSection({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1">
      <div className="px-4 py-2 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide">
        {title}
      </div>
      {children}
    </div>
  );
}

export function Sidebar() {
  const [location] = useLocation();
  const { userProfile } = useAuth();

  // Get counts for badges
  const { data: users } = useFirestoreCollection<User>("users");
  const { data: pendingTasks } = useFirestoreCollection<Task>(
    "tasks",
    [where("status", "!=", "completed")]
  );
  const { data: pendingLeaves } = useFirestoreCollection<Leave>(
    "leaves",
    [where("status", "==", "pending")]
  );

  const employeeCount = users.filter(u => u.role === "employee").length;
  const contractorCount = users.filter(u => u.role === "contractor").length;

  const isActive = (path: string) => location === path;

  if (!userProfile) return null;

  return (
    <aside className="w-64 bg-white dark:bg-dark-card shadow-sm border-r dark:border-dark-border min-h-screen">
      <nav className="p-4 space-y-2">
        {/* Dashboard */}
        <SidebarItem
          href="/dashboard"
          icon="fas fa-home"
          label="Dashboard"
          isActive={isActive("/dashboard")}
        />

        {/* Admin-only sections */}
        {userProfile.role === "admin" && (
          <>
            <SidebarSection title="WORKFORCE">
              <SidebarItem
                href="/users"
                icon="fas fa-users"
                label="Employees"
                badge={employeeCount}
                isActive={isActive("/users")}
              />
              <SidebarItem
                href="/users?tab=contractors"
                icon="fas fa-handshake"
                label="Contractors"
                badge={contractorCount}
                badgeColor="bg-secondary"
                isActive={isActive("/users") && location.includes("contractors")}
              />
            </SidebarSection>

            <SidebarSection title="PROJECTS">
              <SidebarItem
                href="/projects"
                icon="fas fa-project-diagram"
                label="Projects"
                isActive={isActive("/projects")}
              />
              <SidebarItem
                href="/tasks"
                icon="fas fa-tasks"
                label="Tasks"
                badge={pendingTasks.length}
                badgeColor="bg-red-500"
                isActive={isActive("/tasks")}
              />
            </SidebarSection>

            <SidebarSection title="TIME TRACKING">
              <SidebarItem
                href="/attendance"
                icon="fas fa-clock"
                label="Attendance"
                isActive={isActive("/attendance")}
              />
              <SidebarItem
                href="/leave"
                icon="fas fa-calendar-alt"
                label="Leave Requests"
                badge={pendingLeaves.length}
                badgeColor="bg-yellow-500"
                isActive={isActive("/leave")}
              />
            </SidebarSection>

            <SidebarSection title="FINANCIAL">
              <SidebarItem
                href="/invoices"
                icon="fas fa-file-invoice-dollar"
                label="Invoices"
                isActive={isActive("/invoices")}
              />
            </SidebarSection>

            <SidebarSection title="COMMUNICATION">
              <SidebarItem
                href="/notifications"
                icon="fas fa-bullhorn"
                label="Notifications"
                isActive={isActive("/notifications")}
              />
            </SidebarSection>
          </>
        )}

        {/* Employee sections */}
        {userProfile.role === "employee" && (
          <>
            <SidebarSection title="MY WORK">
              <SidebarItem
                href="/tasks"
                icon="fas fa-tasks"
                label="My Tasks"
                isActive={isActive("/tasks")}
              />
              <SidebarItem
                href="/projects"
                icon="fas fa-project-diagram"
                label="My Projects"
                isActive={isActive("/projects")}
              />
            </SidebarSection>

            <SidebarSection title="TIME & LEAVE">
              <SidebarItem
                href="/attendance"
                icon="fas fa-clock"
                label="Attendance"
                isActive={isActive("/attendance")}
              />
              <SidebarItem
                href="/leave"
                icon="fas fa-calendar-alt"
                label="Leave Requests"
                isActive={isActive("/leave")}
              />
            </SidebarSection>

            <SidebarSection title="FINANCIAL">
              <SidebarItem
                href="/invoices"
                icon="fas fa-file-invoice-dollar"
                label="My Salary"
                isActive={isActive("/invoices")}
              />
            </SidebarSection>
          </>
        )}

        {/* Contractor sections */}
        {userProfile.role === "contractor" && (
          <>
            <SidebarSection title="MY WORK">
              <SidebarItem
                href="/tasks"
                icon="fas fa-tasks"
                label="My Tasks"
                isActive={isActive("/tasks")}
              />
              <SidebarItem
                href="/projects"
                icon="fas fa-project-diagram"
                label="My Projects"
                isActive={isActive("/projects")}
              />
            </SidebarSection>

            <SidebarSection title="TIME TRACKING">
              <SidebarItem
                href="/attendance"
                icon="fas fa-clock"
                label="Time Tracking"
                isActive={isActive("/attendance")}
              />
            </SidebarSection>

            <SidebarSection title="FINANCIAL">
              <SidebarItem
                href="/invoices"
                icon="fas fa-file-invoice-dollar"
                label="Invoices"
                isActive={isActive("/invoices")}
              />
            </SidebarSection>
          </>
        )}

        {/* Common sections for employees and contractors */}
        {(userProfile.role === "employee" || userProfile.role === "contractor") && (
          <SidebarSection title="COMMUNICATION">
            <SidebarItem
              href="/notifications"
              icon="fas fa-bullhorn"
              label="Announcements"
              isActive={isActive("/notifications")}
            />
          </SidebarSection>
        )}
      </nav>
    </aside>
  );
}
