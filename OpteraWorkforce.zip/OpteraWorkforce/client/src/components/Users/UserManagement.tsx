import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useAuth } from "@/hooks/useAuth";
import { useFirestoreCollection, addFirestoreDocument, updateFirestoreDocument } from "@/hooks/useFirestore";
import { User, InsertUser } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { createUserWithEmailAndPassword } from "firebase/auth";
import { doc, setDoc } from "firebase/firestore";
import { auth, db } from "@/lib/firebase";

export function UserManagement() {
  const { userProfile } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("employees");
  const [isAddUserOpen, setIsAddUserOpen] = useState(false);
  const [loading, setLoading] = useState(false);

  const { data: users } = useFirestoreCollection<User>("users");

  const [newUser, setNewUser] = useState<InsertUser & { password: string }>({
    role: "employee",
    name: "",
    email: "",
    position: "",
    salary: 0,
    contractRate: 0,
    overtimeRate: 0,
    password: "",
  });

  // Only admin can manage users
  if (userProfile?.role !== "admin") {
    return (
      <div className="text-center py-8">
        <p className="text-gray-500 dark:text-gray-400">Access denied. Admin privileges required.</p>
      </div>
    );
  }

  const employees = users.filter(u => u.role === "employee");
  const contractors = users.filter(u => u.role === "contractor");

  const handleAddUser = async () => {
    if (!newUser.name || !newUser.email || !newUser.password) {
      toast({
        title: "Error",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    try {
      // Create user in Firebase Auth
      const userCredential = await createUserWithEmailAndPassword(auth, newUser.email, newUser.password);
      const uid = userCredential.user.uid;

      // Create user profile in Firestore
      const userData = {
        uid,
        role: newUser.role,
        name: newUser.name,
        email: newUser.email,
        position: newUser.position || "",
        salary: newUser.role === "employee" ? newUser.salary : undefined,
        contractRate: newUser.role === "contractor" ? newUser.contractRate : undefined,
        overtimeRate: newUser.overtimeRate,
        isActive: true,
        createdAt: new Date(),
      };

      await setDoc(doc(db, "users", uid), userData);

      toast({
        title: "Success",
        description: `${newUser.role} added successfully!`,
      });

      setIsAddUserOpen(false);
      setNewUser({
        role: "employee",
        name: "",
        email: "",
        position: "",
        salary: 0,
        contractRate: 0,
        overtimeRate: 0,
        password: "",
      });
    } catch (error: any) {
      console.error("Add user error:", error);
      toast({
        title: "Error",
        description: error.message || "Failed to add user.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleDeactivateUser = async (userId: string) => {
    try {
      await updateFirestoreDocument("users", userId, { isActive: false });
      toast({
        title: "Success",
        description: "User deactivated successfully.",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to deactivate user.",
        variant: "destructive",
      });
    }
  };

  const UserTable = ({ users, type }: { users: User[]; type: string }) => (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span>{type} ({users.length})</span>
          <Dialog open={isAddUserOpen} onOpenChange={setIsAddUserOpen}>
            <DialogTrigger asChild>
              <Button 
                className="bg-primary hover:bg-blue-700"
                onClick={() => setNewUser(prev => ({ ...prev, role: type === "Employees" ? "employee" : "contractor" }))}
                data-testid={`button-add-${type.toLowerCase().slice(0, -1)}`}
              >
                <i className="fas fa-plus mr-2"></i>
                Add {type.slice(0, -1)}
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>Add New {type.slice(0, -1)}</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="name">Full Name *</Label>
                  <Input
                    id="name"
                    value={newUser.name}
                    onChange={(e) => setNewUser(prev => ({ ...prev, name: e.target.value }))}
                    placeholder="Enter full name"
                    data-testid="input-user-name"
                  />
                </div>
                
                <div>
                  <Label htmlFor="email">Email Address *</Label>
                  <Input
                    id="email"
                    type="email"
                    value={newUser.email}
                    onChange={(e) => setNewUser(prev => ({ ...prev, email: e.target.value }))}
                    placeholder="Enter email address"
                    data-testid="input-user-email"
                  />
                </div>
                
                <div>
                  <Label htmlFor="password">Password *</Label>
                  <Input
                    id="password"
                    type="password"
                    value={newUser.password}
                    onChange={(e) => setNewUser(prev => ({ ...prev, password: e.target.value }))}
                    placeholder="Enter password"
                    data-testid="input-user-password"
                  />
                </div>
                
                <div>
                  <Label htmlFor="position">Position</Label>
                  <Input
                    id="position"
                    value={newUser.position}
                    onChange={(e) => setNewUser(prev => ({ ...prev, position: e.target.value }))}
                    placeholder="Enter position/title"
                    data-testid="input-user-position"
                  />
                </div>
                
                {newUser.role === "employee" && (
                  <div>
                    <Label htmlFor="salary">Monthly Salary ($)</Label>
                    <Input
                      id="salary"
                      type="number"
                      value={newUser.salary}
                      onChange={(e) => setNewUser(prev => ({ ...prev, salary: Number(e.target.value) }))}
                      placeholder="Enter monthly salary"
                      data-testid="input-user-salary"
                    />
                  </div>
                )}
                
                {newUser.role === "contractor" && (
                  <div>
                    <Label htmlFor="contractRate">Hourly Rate ($)</Label>
                    <Input
                      id="contractRate"
                      type="number"
                      value={newUser.contractRate}
                      onChange={(e) => setNewUser(prev => ({ ...prev, contractRate: Number(e.target.value) }))}
                      placeholder="Enter hourly rate"
                      data-testid="input-user-contract-rate"
                    />
                  </div>
                )}
                
                <div>
                  <Label htmlFor="overtimeRate">Overtime Rate ($/hour)</Label>
                  <Input
                    id="overtimeRate"
                    type="number"
                    value={newUser.overtimeRate}
                    onChange={(e) => setNewUser(prev => ({ ...prev, overtimeRate: Number(e.target.value) }))}
                    placeholder="Enter overtime rate"
                    data-testid="input-user-overtime-rate"
                  />
                </div>
                
                <div className="flex space-x-2 pt-4">
                  <Button
                    onClick={handleAddUser}
                    disabled={loading}
                    className="flex-1 bg-primary hover:bg-blue-700"
                    data-testid="button-save-user"
                  >
                    {loading ? (
                      <>
                        <i className="fas fa-spinner fa-spin mr-2"></i>
                        Adding...
                      </>
                    ) : (
                      "Add User"
                    )}
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => setIsAddUserOpen(false)}
                    disabled={loading}
                    data-testid="button-cancel-user"
                  >
                    Cancel
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Name</TableHead>
              <TableHead>Email</TableHead>
              <TableHead>Position</TableHead>
              <TableHead>{type === "Employees" ? "Salary" : "Rate"}</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {users.map((user) => (
              <TableRow key={user.uid} data-testid={`row-user-${user.uid}`}>
                <TableCell>
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                      <span className="text-white text-sm font-medium">
                        {user.name.split(' ').map(n => n[0]).join('').slice(0, 2)}
                      </span>
                    </div>
                    <span className="font-medium">{user.name}</span>
                  </div>
                </TableCell>
                <TableCell>{user.email}</TableCell>
                <TableCell>{user.position || "-"}</TableCell>
                <TableCell>
                  {user.role === "employee" 
                    ? `$${user.salary?.toLocaleString() || 0}/month`
                    : `$${user.contractRate || 0}/hour`
                  }
                </TableCell>
                <TableCell>
                  <Badge variant={user.isActive ? "default" : "secondary"}>
                    {user.isActive ? "Active" : "Inactive"}
                  </Badge>
                </TableCell>
                <TableCell>
                  <div className="flex space-x-2">
                    <Button size="sm" variant="outline" data-testid={`button-edit-user-${user.uid}`}>
                      <i className="fas fa-edit"></i>
                    </Button>
                    {user.isActive && (
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => handleDeactivateUser(user.uid)}
                        data-testid={`button-deactivate-user-${user.uid}`}
                      >
                        <i className="fas fa-ban text-red-500"></i>
                      </Button>
                    )}
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
        
        {users.length === 0 && (
          <div className="text-center py-8">
            <p className="text-gray-500 dark:text-gray-400">No {type.toLowerCase()} found</p>
          </div>
        )}
      </CardContent>
    </Card>
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">User Management</h1>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="employees" data-testid="tab-employees">
            Employees ({employees.length})
          </TabsTrigger>
          <TabsTrigger value="contractors" data-testid="tab-contractors">
            Contractors ({contractors.length})
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="employees">
          <UserTable users={employees} type="Employees" />
        </TabsContent>
        
        <TabsContent value="contractors">
          <UserTable users={contractors} type="Contractors" />
        </TabsContent>
      </Tabs>
    </div>
  );
}
