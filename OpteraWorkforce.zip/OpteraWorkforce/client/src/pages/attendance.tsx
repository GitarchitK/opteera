import { Layout } from "@/components/Layout/Layout";
import { AttendanceManagement } from "@/components/Attendance/AttendanceManagement";

export default function AttendancePage() {
  return (
    <Layout>
      <AttendanceManagement />
    </Layout>
  );
}
