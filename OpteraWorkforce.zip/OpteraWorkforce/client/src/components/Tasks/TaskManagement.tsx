import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useAuth } from "@/hooks/useAuth";
import { useFirestoreCollection, addFirestoreDocument, updateFirestoreDocument } from "@/hooks/useFirestore";
import { Task, Project, User, InsertTask } from "@shared/schema";
import { where } from "firebase/firestore";
import { formatDisplayDate } from "@/utils/dateHelpers";
import { useToast } from "@/hooks/use-toast";

export function TaskManagement() {
  const { userProfile } = useAuth();
  const { toast } = useToast();
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState("all");

  const { data: allTasks } = useFirestoreCollection<Task>("tasks");
  const { data: projects } = useFirestoreCollection<Project>("projects");
  const { data: users } = useFirestoreCollection<User>("users");

  // Filter tasks based on user role
  const tasks = userProfile?.role === "admin" 
    ? allTasks
    : allTasks.filter(t => t.assignedTo === userProfile?.uid);

  const [newTask, setNewTask] = useState<InsertTask>({
    title: "",
    description: "",
    assignedTo: "",
    projectId: "",
    deadline: new Date(),
    status: "pending",
    priority: "medium",
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed": return "bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400";
      case "in-progress": return "bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-400";
      case "pending": return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-400";
      default: return "bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-400";
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high": return "bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-400";
      case "medium": return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-400";
      case "low": return "bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400";
      default: return "bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-400";
    }
  };

  const isOverdue = (task: Task) => {
    return task.status !== "completed" && new Date() > task.deadline;
  };

  const filteredTasks = tasks.filter(task => {
    switch (activeTab) {
      case "pending": return task.status === "pending";
      case "in-progress": return task.status === "in-progress";
      case "completed": return task.status === "completed";
      case "overdue": return isOverdue(task);
      default: return true;
    }
  });

  const handleCreateTask = async () => {
    if (!newTask.title || !newTask.assignedTo || !newTask.projectId) {
      toast({
        title: "Error",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    try {
      await addFirestoreDocument("tasks", {
        ...newTask,
        taskId: `task_${Date.now()}`,
      });

      toast({
        title: "Success",
        description: "Task created successfully!",
      });

      setIsCreateOpen(false);
      setNewTask({
        title: "",
        description: "",
        assignedTo: "",
        projectId: "",
        deadline: new Date(),
        status: "pending",
        priority: "medium",
      });
    } catch (error) {
      console.error("Create task error:", error);
      toast({
        title: "Error",
        description: "Failed to create task.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateTaskStatus = async (taskId: string, newStatus: Task["status"]) => {
    try {
      await updateFirestoreDocument("tasks", taskId, { status: newStatus });
      toast({
        title: "Success",
        description: "Task status updated successfully.",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update task status.",
        variant: "destructive",
      });
    }
  };

  const getProjectName = (projectId: string) => {
    const project = projects.find(p => p.projectId === projectId);
    return project?.name || "Unknown Project";
  };

  const getUserName = (userId: string) => {
    const user = users.find(u => u.uid === userId);
    return user?.name || "Unknown User";
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
          {userProfile?.role === "admin" ? "Task Management" : "My Tasks"}
        </h1>
        
        {userProfile?.role === "admin" && (
          <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
            <DialogTrigger asChild>
              <Button className="bg-primary hover:bg-blue-700" data-testid="button-create-task">
                <i className="fas fa-plus mr-2"></i>
                Create Task
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>Create New Task</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="title">Task Title *</Label>
                  <Input
                    id="title"
                    value={newTask.title}
                    onChange={(e) => setNewTask(prev => ({ ...prev, title: e.target.value }))}
                    placeholder="Enter task title"
                    data-testid="input-task-title"
                  />
                </div>
                
                <div>
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    value={newTask.description}
                    onChange={(e) => setNewTask(prev => ({ ...prev, description: e.target.value }))}
                    placeholder="Enter task description"
                    rows={3}
                    data-testid="textarea-task-description"
                  />
                </div>

                <div>
                  <Label htmlFor="project">Project *</Label>
                  <Select
                    value={newTask.projectId}
                    onValueChange={(value) => setNewTask(prev => ({ ...prev, projectId: value }))}
                  >
                    <SelectTrigger data-testid="select-task-project">
                      <SelectValue placeholder="Select project" />
                    </SelectTrigger>
                    <SelectContent>
                      {projects.filter(p => p.status === "active").map((project) => (
                        <SelectItem key={project.projectId} value={project.projectId!}>
                          {project.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="assignedTo">Assign To *</Label>
                  <Select
                    value={newTask.assignedTo}
                    onValueChange={(value) => setNewTask(prev => ({ ...prev, assignedTo: value }))}
                  >
                    <SelectTrigger data-testid="select-task-assignee">
                      <SelectValue placeholder="Select assignee" />
                    </SelectTrigger>
                    <SelectContent>
                      {users.filter(u => u.role !== "admin" && u.isActive).map((user) => (
                        <SelectItem key={user.uid} value={user.uid}>
                          {user.name} ({user.role})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="deadline">Deadline</Label>
                  <Input
                    id="deadline"
                    type="date"
                    value={newTask.deadline.toISOString().split('T')[0]}
                    onChange={(e) => setNewTask(prev => ({ ...prev, deadline: new Date(e.target.value) }))}
                    data-testid="input-task-deadline"
                  />
                </div>

                <div>
                  <Label htmlFor="priority">Priority</Label>
                  <Select
                    value={newTask.priority}
                    onValueChange={(value) => setNewTask(prev => ({ ...prev, priority: value as Task["priority"] }))}
                  >
                    <SelectTrigger data-testid="select-task-priority">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="flex space-x-2 pt-4">
                  <Button
                    onClick={handleCreateTask}
                    disabled={loading}
                    className="flex-1 bg-primary hover:bg-blue-700"
                    data-testid="button-save-task"
                  >
                    {loading ? (
                      <>
                        <i className="fas fa-spinner fa-spin mr-2"></i>
                        Creating...
                      </>
                    ) : (
                      "Create Task"
                    )}
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => setIsCreateOpen(false)}
                    disabled={loading}
                    data-testid="button-cancel-task"
                  >
                    Cancel
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        )}
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="all" data-testid="tab-all-tasks">
            All ({tasks.length})
          </TabsTrigger>
          <TabsTrigger value="pending" data-testid="tab-pending-tasks">
            Pending ({tasks.filter(t => t.status === "pending").length})
          </TabsTrigger>
          <TabsTrigger value="in-progress" data-testid="tab-in-progress-tasks">
            In Progress ({tasks.filter(t => t.status === "in-progress").length})
          </TabsTrigger>
          <TabsTrigger value="completed" data-testid="tab-completed-tasks">
            Completed ({tasks.filter(t => t.status === "completed").length})
          </TabsTrigger>
          <TabsTrigger value="overdue" data-testid="tab-overdue-tasks">
            Overdue ({tasks.filter(t => isOverdue(t)).length})
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value={activeTab} className="space-y-4">
          {filteredTasks.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredTasks.map((task) => (
                <Card key={task.taskId} className="bg-white dark:bg-dark-card border dark:border-dark-border" data-testid={`card-task-${task.taskId}`}>
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <CardTitle className="text-lg text-gray-900 dark:text-white">
                          {task.title}
                        </CardTitle>
                        <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                          {getProjectName(task.projectId)}
                        </p>
                      </div>
                      <div className="flex flex-col space-y-1">
                        <Badge className={getStatusColor(task.status)}>
                          {task.status}
                        </Badge>
                        <Badge className={getPriorityColor(task.priority)}>
                          {task.priority}
                        </Badge>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {task.description && (
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        {task.description}
                      </p>
                    )}
                    
                    <div className="space-y-2 text-sm">
                      {userProfile?.role === "admin" && (
                        <div className="flex justify-between">
                          <span className="text-gray-600 dark:text-gray-400">Assigned to:</span>
                          <span className="font-medium">{getUserName(task.assignedTo)}</span>
                        </div>
                      )}
                      
                      <div className="flex justify-between">
                        <span className="text-gray-600 dark:text-gray-400">Deadline:</span>
                        <span className={`font-medium ${isOverdue(task) ? 'text-red-600 dark:text-red-400' : ''}`}>
                          {formatDisplayDate(task.deadline)}
                        </span>
                      </div>
                    </div>

                    {isOverdue(task) && (
                      <div className="p-2 bg-red-50 dark:bg-red-900/20 rounded border border-red-200 dark:border-red-800">
                        <p className="text-xs text-red-700 dark:text-red-400">
                          <i className="fas fa-exclamation-triangle mr-1"></i>
                          This task is overdue
                        </p>
                      </div>
                    )}

                    {(userProfile?.uid === task.assignedTo || userProfile?.role === "admin") && (
                      <div className="pt-2 border-t border-gray-200 dark:border-gray-700">
                        <Select
                          value={task.status}
                          onValueChange={(value) => handleUpdateTaskStatus(task.taskId!, value as Task["status"])}
                        >
                          <SelectTrigger className="w-full" data-testid={`select-task-status-${task.taskId}`}>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="pending">Pending</SelectItem>
                            <SelectItem value="in-progress">In Progress</SelectItem>
                            <SelectItem value="completed">Completed</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <Card className="bg-white dark:bg-dark-card border dark:border-dark-border">
              <CardContent className="text-center py-8">
                <i className="fas fa-tasks text-4xl text-gray-400 mb-4"></i>
                <p className="text-gray-500 dark:text-gray-400">
                  No tasks found for the selected filter.
                </p>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
