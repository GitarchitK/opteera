import { Layout } from "@/components/Layout/Layout";
import { LeaveManagement } from "@/components/Leave/LeaveManagement";

export default function LeavePage() {
  return (
    <Layout>
      <LeaveManagement />
    </Layout>
  );
}
