import { Layout } from "@/components/Layout/Layout";
import { ProjectManagement } from "@/components/Projects/ProjectManagement";

export default function ProjectsPage() {
  return (
    <Layout>
      <ProjectManagement />
    </Layout>
  );
}
