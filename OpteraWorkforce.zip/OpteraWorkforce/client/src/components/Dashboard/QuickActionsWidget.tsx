import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useFirestoreCollection } from "@/hooks/useFirestore";
import { Invoice } from "@shared/schema";
import { formatDisplayDate } from "@/utils/dateHelpers";
import { Link } from "wouter";

export function QuickActionsWidget() {
  const { data: recentInvoices } = useFirestoreCollection<Invoice>("invoices");

  // Get the most recent invoices
  const sortedInvoices = recentInvoices
    .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
    .slice(0, 3);

  const handleDownloadInvoice = (invoiceId: string) => {
    // This would implement PDF download functionality
    console.log("Downloading invoice:", invoiceId);
  };

  return (
    <Card className="bg-white dark:bg-dark-card border dark:border-dark-border">
      <CardContent className="p-6">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-6">
          Quick Actions
        </h3>
        
        <div className="grid grid-cols-2 gap-4">
          <Link href="/users">
            <Button
              variant="outline"
              className="p-4 border-2 border-dashed border-primary rounded-lg hover:bg-blue-50 dark:hover:bg-primary/10 transition-colors h-auto flex-col space-y-2"
              data-testid="button-add-employee"
            >
              <i className="fas fa-user-plus text-primary text-2xl"></i>
              <span className="font-medium text-gray-900 dark:text-white">Add Employee</span>
            </Button>
          </Link>
          
          <Link href="/users">
            <Button
              variant="outline"
              className="p-4 border-2 border-dashed border-secondary rounded-lg hover:bg-orange-50 dark:hover:bg-secondary/10 transition-colors h-auto flex-col space-y-2"
              data-testid="button-add-contractor"
            >
              <i className="fas fa-handshake text-secondary text-2xl"></i>
              <span className="font-medium text-gray-900 dark:text-white">Add Contractor</span>
            </Button>
          </Link>
          
          <Link href="/projects">
            <Button
              variant="outline"
              className="p-4 border-2 border-dashed border-green-500 rounded-lg hover:bg-green-50 dark:hover:bg-green-500/10 transition-colors h-auto flex-col space-y-2"
              data-testid="button-create-project"
            >
              <i className="fas fa-project-diagram text-green-500 text-2xl"></i>
              <span className="font-medium text-gray-900 dark:text-white">New Project</span>
            </Button>
          </Link>
          
          <Link href="/notifications">
            <Button
              variant="outline"
              className="p-4 border-2 border-dashed border-purple-500 rounded-lg hover:bg-purple-50 dark:hover:bg-purple-500/10 transition-colors h-auto flex-col space-y-2"
              data-testid="button-send-notification"
            >
              <i className="fas fa-bullhorn text-purple-500 text-2xl"></i>
              <span className="font-medium text-gray-900 dark:text-white">Send Notice</span>
            </Button>
          </Link>
        </div>
        
        {/* Recent Invoices */}
        <div className="mt-6 pt-6 border-t dark:border-dark-border">
          <div className="flex items-center justify-between mb-4">
            <h4 className="font-medium text-gray-900 dark:text-white">Recent Invoices</h4>
            <Link href="/invoices">
              <Button variant="ghost" className="text-primary hover:text-blue-700 text-sm" data-testid="button-generate-invoices">
                Generate
              </Button>
            </Link>
          </div>
          
          <div className="space-y-3">
            {sortedInvoices.length > 0 ? (
              sortedInvoices.map((invoice) => (
                <div
                  key={invoice.invoiceId}
                  className="flex items-center justify-between"
                  data-testid={`card-invoice-${invoice.invoiceId}`}
                >
                  <div className="flex items-center space-x-3">
                    <i className="fas fa-file-invoice text-gray-400"></i>
                    <div>
                      <p className="text-sm font-medium text-gray-900 dark:text-white">
                        {invoice.month} {invoice.year}
                      </p>
                      <p className="text-xs text-gray-500 dark:text-gray-400">
                        Generated {formatDisplayDate(invoice.createdAt)}
                      </p>
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-primary hover:text-blue-700 text-sm"
                    onClick={() => handleDownloadInvoice(invoice.invoiceId!)}
                    data-testid={`button-download-invoice-${invoice.invoiceId}`}
                  >
                    <i className="fas fa-download"></i>
                  </Button>
                </div>
              ))
            ) : (
              <div className="text-center py-4 text-gray-500 dark:text-gray-400">
                <p className="text-sm">No invoices generated yet</p>
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
