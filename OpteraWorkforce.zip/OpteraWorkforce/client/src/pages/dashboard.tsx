import { useAuth } from "@/hooks/useAuth";
import { Layout } from "@/components/Layout/Layout";
import { AdminDashboard } from "@/components/Dashboard/AdminDashboard";
import { EmployeeDashboard } from "@/components/Dashboard/EmployeeDashboard";
import { ContractorDashboard } from "@/components/Dashboard/ContractorDashboard";

export default function DashboardPage() {
  const { userProfile } = useAuth();

  if (!userProfile) return null;

  const renderDashboard = () => {
    switch (userProfile.role) {
      case "admin":
        return <AdminDashboard />;
      case "employee":
        return <EmployeeDashboard />;
      case "contractor":
        return <ContractorDashboard />;
      default:
        return <div>Unknown role</div>;
    }
  };

  return (
    <Layout>
      {renderDashboard()}
    </Layout>
  );
}
