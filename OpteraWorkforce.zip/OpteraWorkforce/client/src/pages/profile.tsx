import { Layout } from "@/components/Layout/Layout";
import { ProfileManagement } from "@/components/Profile/ProfileManagement";

export default function ProfilePage() {
  return (
    <Layout>
      <ProfileManagement />
    </Layout>
  );
}
